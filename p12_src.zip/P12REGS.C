#ifdef NEVERDEF
/****************************************************************************
 ****************************************************************************
 *                                                                          *
 *   WARNING!                                                               *
 *                                                                          *
 *   I've discovered a bug in the code optimizer.  A definition like:       *
 *      #define TESTBITS (BIT1|BIT2)                                        *
 *   can produce incorrect code output from the optimizer when TESTBITS     *
 *   is used.                                                               *
 *                                                                          *
 *   Instead, use a definition like:                                        *
 *      #define TESTBITS 0x05  /* (BIT1|BIT2) */                            *
 *   Yes, that's not as "ideal", but it will save a WORLD of problems!      *
 *                                                                          *
 ****************************************************************************
 ****************************************************************************/
#endif

/*
 *  PIC emulator.  12C509A version.
 *  Register access functions
 *
 *
 *  Copyright (c) 2001-2004
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICEMU
 *
 *  PICEMU is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICEMU is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *
 *  Revision history
 *
 *  Date      Comments
 *  --------  ---------------------------------------------
 *  9/xx/01   Original code
 *  11/14/01  Code cleanup for 1st BETA release
 *  2/20/04   New commands, add analog inputs
 *  3/15/04   Source code unification for 14-bit core programs.
 */

#include <picemu.h>

extern WORD filenum_temp;
extern WORD filenum_temp2;
extern BYTE regs[MAX_NUM_REGS];

extern BYTE input_ports[NUM_BYTE_PORTS_ALLOCATE];
extern BYTE port_masks[NUM_BYTE_PORTS_ALLOCATE];
extern WORD analog_ports[NUM_BYTE_PORTS][8];
extern BYTE regval;
extern WORD ip;  /* for write to PCL reg */
extern WORD tmr0_inhibit;  /* if write to TMR0, inhibit TIMER0 update for
                              2 instruction cycles */
extern WORD tmr0_prescale;
extern WORD tmr0_prescale_counter;   /* TMR0 / watchdog prescale counter */
extern WORD sleepmode;     /* for TIMER 0 in counter mode */
extern WORD last_t0cki;    /* for T0CKI edge detection */
extern WORD do_mclr_reset;   /* time to do a MCLR reset */
extern WORD configuration;   /* test MCLR pin current definition */
extern WORD readusestris;

extern WORD bittable[8];   /* bit mask, indexed by bit number */

extern WORD timingcount;

extern WORD breakpoint;
extern WORD noexecute;
extern WORD num_reg_breakpoints;
extern struct regbreaks reg_breaks[MAX_REG_BREAKS];

extern WORD show_ports;

extern WORD doing_portwrite;
extern WORD doing_portread;

#ifdef USE_ADDRLIST
   extern WORD addrlist_seg;
   extern WORD addrlist;
   extern WORD wherequeue[WHERE_SIZE+1];  /* queue of addresses for where? */
   extern WORD whereptr;  /* pointer into "where was I?" queue */
#endif  /* USE_ADDRLIST */

#ifdef HAS_UART
   #define BAUDTABLE_SIZE 10     /* local for set_baudrate(), can be here */
                                 /* instead of picemu.h */
   DWORD baudtable[BAUDTABLE_SIZE] =
      {
         110,
         300,
        1200,
        2400,
        4800,
        9600,
       19200,
       38400,
       57600,
      115200
      };
#endif  /* HAS_UART */

void code_alignment_2()
   {
#ifdef R_1B
#asm
   nop        ;code alignment
#endasm
#endif  /* R_1B */

#ifdef R_2B
#asm
   nop        ;code alignment
   nop        ;code alignment
#endasm
#endif  /* R_2B */

#ifdef R_4B
#asm
   nop        ;code alignment
   nop        ;code alignment
   nop        ;code alignment
   nop        ;code alignment
#endasm
#endif  /* R_4B */

#ifdef R_8B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
#endasm
#endif  /* R_8B */

#ifdef R_16B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
   nop        ;code alignment  9
   nop        ;code alignment  10
   nop        ;code alignment  11
   nop        ;code alignment  12
   nop        ;code alignment  13
   nop        ;code alignment  14
   nop        ;code alignment  15
   nop        ;code alignment  16
#endasm
#endif  /* R_16B */

#ifdef R_32B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
   nop        ;code alignment  9
   nop        ;code alignment  10
   nop        ;code alignment  11
   nop        ;code alignment  12
   nop        ;code alignment  13
   nop        ;code alignment  14
   nop        ;code alignment  15
   nop        ;code alignment  16
   nop        ;code alignment  17
   nop        ;code alignment  18
   nop        ;code alignment  19
   nop        ;code alignment  20
   nop        ;code alignment  21
   nop        ;code alignment  22
   nop        ;code alignment  23
   nop        ;code alignment  24
   nop        ;code alignment  25
   nop        ;code alignment  26
   nop        ;code alignment  27
   nop        ;code alignment  28
   nop        ;code alignment  29
   nop        ;code alignment  30
   nop        ;code alignment  31
   nop        ;code alignment  32
#endasm
#endif  /* R_32B */
   }

BYTE r_reg()
   {
   return(regs[filenum_temp2]);
   }

BYTE r_none()
   {
   return(0);
   }

BYTE r_gpio()
   {
#ifdef READ_USES_TRIS
   BYTE temp, temp2;  /* keep stuff aligned on stack */
   BYTE mask, mask2;

   if (readusestris)
      {
      mask = regs[TRISA] | GP3;  /* GP3 is always an input */
      if (regs[OPTION] & T0CS)  /* T0CS forces GP2 to be an input despite TRIS */
         mask |= GP2;
      return(regs[GPIO] = (((regs[GPIO] & ~mask) | (input_ports[0] & mask)) & port_masks[0]));
      }
/* #else */
   doing_portread = TRUE;  /* mostly for BSF / BCF */
   return(input_ports[0] & port_masks[0]);
#endif  /* READ_USES_TRIS */
#ifdef NEVERDEF
   temp = ((regs[GPIO] & ~mask) | (input_ports[0] & mask)) & port_masks[0];
   if (regs[OPTION] & T0CS)  /* if GP2 is T0CKI, it is read as 0 */
      temp &= NOT_BIT2;
   return(TEMP);
#endif  /* NEVERDEF */
   }

void w_reg()
   {
   regs[filenum_temp2] = regval;
   }

void w_tmr0()
   {
   regs[TMR0] = regval;
   tmr0_inhibit = 3;  /* inhibit TMR0 update for 2 instruction cycles */
                      /* Yup, I mean 3! */
   if (!(regs[OPTION] & PSA))  /* if prescalar assigned to TMR0 */
      tmr0_prescale_counter = 0;
   }

void w_status()
   {
   regs[STATUS] = (regs[STATUS] & 0x18) | (regval & 0xa7);
      /* cannot set !TO, !PD bits */
      /* bit 6 not implemented */
   }

void w_pcl()
   {
   regs[PCL] = regval;
   ip = ((WORD)(regs[STATUS] & STATUS_PA0) << STATUS_PA0_SHIFT) + regs[PCL];
        /* note that bit 8 is implicitly cleared */
   timingcount++;  /* NOPs now in prefetch queue */
   }

void w_osccal()
   {
   regs[OSCCAL] = regval & 0xfc;  /* high 6 bits only */
   }

void w_gpio()
   {
   regs[GPIO] = regval & 0x3f;  /* low 6 bits only */
   doing_portwrite = TRUE;
   io_processing();
   doing_portwrite = FALSE;
   }

w_fsr()
   {
   regs[FSR] = RESET_FSR | regval;  /* upper bits are always 1 */
   }

void w_none()
   {
   }

#ifdef PICTYPE_12C509A
   #include "p509regs.h"
#endif  /* PICTYPE_12C509A */

/*
 *  Note:  there is no special code to make sure that an indirect read
 *         of register 0 returns 0.  Since register 0 cannot be set,
 *         it will always contain 0.
 */
BYTE read_regs()
   {
   WORD loopcounter;
   WORD checkval;
   BYTE tempval, maskedval;

   checkval = 0;  /* default:  do not need to check value filenum_tempx */
#ifdef SLOW_REGBREAK_CHECKS
   if (num_reg_breakpoints)
      for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
         {
         if ((reg_breaks[loopcounter].type & REGBREAK_READ)
                  && (reg_breaks[loopcounter].low <= filenum_temp)
                  && (reg_breaks[loopcounter].high >= filenum_temp))
            {
            if (reg_breaks[loopcounter].have_value)
               {
               checkval |= 1;
               continue;  /* at this level, can't detect a value/masked breakpoint */
               }
            breakpoint = BRK_REGISTER;
            noexecute = TRUE;
            break;
            }
         }
#endif  /* SLOW_REGBREAK_CHECKS */
   filenum_temp2 = xlate_regs[filenum_temp];  /* lookup actual reg index */
#ifdef USE_ADDRLIST
   if ((addrlist)
        && ((loopcounter = peekw(addrlist_seg,wherequeue[whereptr]<<1)) != 0xffff)
        && (loopcounter != filenum_temp2))
            /* use loopcounter as a temp value */
      {
      breakpoint = BRK_ADDRLIST;
      noexecute = TRUE;
      }
#endif  /* USE_ADDRLIST */
   if (filenum_temp2 == INDF)  /* if indirect */
      {
      if (num_reg_breakpoints)
         for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
            {
            if ((reg_breaks[loopcounter].type & REGBREAK_READ)
                     && (reg_breaks[loopcounter].low <= INDF)
                     && (reg_breaks[loopcounter].high >= INDF))
               {
               if (reg_breaks[loopcounter].have_value)
                  {
                  checkval |= 4;
                  continue;  /* at this level, can't detect a value/masked breakpoint */
                  }
               breakpoint = BRK_REGISTER;
               noexecute = TRUE;
               break;
               }
            }
#ifdef HAS_IRP
      filenum_temp2 = xlate_regs[(WORD)regs[FSR] + (((WORD)regs[STATUS] & STATUS_IRP) << 1)];
#else
      filenum_temp2 = xlate_regs[(WORD)regs[FSR] & FSR_MASK];
#endif  /* HAS_IRP */
      }
   if (num_reg_breakpoints)
#ifdef SLOW_REGBREAK_CHECKS
      if (filenum_temp2 != filenum_temp)  /* if we haven't checked this already */
#endif  /* SLOW_REGBREAK_CHECKS */
         for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
            {
            if ((reg_breaks[loopcounter].type & REGBREAK_READ)
                     && (reg_breaks[loopcounter].low <= filenum_temp2)
                     && (reg_breaks[loopcounter].high >= filenum_temp2))
               {
               if (reg_breaks[loopcounter].have_value)
                  {
                  checkval |= 2;
                  continue;  /* at this level, can't detect a value/masked breakpoint */
                  }
               breakpoint = BRK_REGISTER;
               noexecute = TRUE;
               break;
               }
            }
   if (noexecute)  /* do not use variable breakpoint, do not confuse with user hotkey */
      return(0);  /* note:  if a breakpoint, don't read reg because we could
                   *        do something irreversable
                   */
   tempval = (*readregs[filenum_temp2])();
   if (checkval)
      {
      for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
         {
         if ((reg_breaks[loopcounter].type & REGBREAK_READ)
               && (
                      ((checkval & 1)
                        && (reg_breaks[loopcounter].low <= filenum_temp)
                        && (reg_breaks[loopcounter].high >= filenum_temp))
                 ||
                      ((checkval & 2)
                        && (reg_breaks[loopcounter].low <= filenum_temp2)
                        && (reg_breaks[loopcounter].high >= filenum_temp2))
                 ||
                      ((checkval & 4)
                        && (reg_breaks[loopcounter].low <= INDF)
                        && (reg_breaks[loopcounter].high >= INDF))
                 )
            )
            {
            if (reg_breaks[loopcounter].have_value)
               {
               maskedval = tempval & reg_breaks[loopcounter].mask;
               if (maskedval == reg_breaks[loopcounter].value)
                  {
                  breakpoint = BRK_REGREADVAL;
                  return(tempval);
                  }
               }  /* if (reg_breaks[loopcounter].have_value) */
            }  /* if ((reg_breaks[loopcounter].type...) */
         }  /* for (loopcounter...) */
      }
   return(tempval);
   }

void write_regs()
   {
   WORD loopcounter;

#ifdef SLOW_REGBREAK_CHECKS
   if (num_reg_breakpoints)
      for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
         {
         if ((reg_breaks[loopcounter].type & REGBREAK_WRITE)
                  && (reg_breaks[loopcounter].low <= filenum_temp)
                  && (reg_breaks[loopcounter].high >= filenum_temp))
            {
            if (reg_breaks[loopcounter].have_value)
               {
               if ((regval & reg_breaks[loopcounter].mask) != reg_breaks[loopcounter].value)
                  continue;  /* nope, this break does not apply */
               breakpoint = BRK_REGWRITEVAL;
               }
            else
               breakpoint = BRK_REGISTER;
            noexecute = TRUE;
            break;
            }
         }
#endif  /* SLOW_REGBREAK_CHECKS */
   filenum_temp2 = xlate_regs[filenum_temp];  /* lookup actual reg index */
#ifdef USE_ADDRLIST
   if ((addrlist)
        && ((loopcounter = peekw(addrlist_seg,wherequeue[whereptr]<<1)) != 0xffff)
        && (loopcounter != filenum_temp2))
            /* use loopcounter as a temp value */
      {
      breakpoint = BRK_ADDRLIST;
      noexecute = TRUE;
      }
#endif  /* USE_ADDRLIST */
   if (filenum_temp2 == INDF)  /* if indirect */
      {
      if (num_reg_breakpoints)
         for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
            {
            if ((reg_breaks[loopcounter].type & REGBREAK_WRITE)
                     && (reg_breaks[loopcounter].low <= INDF)
                     && (reg_breaks[loopcounter].high >= INDF))
               {
               if (reg_breaks[loopcounter].have_value)
                  {
                  if ((regval & reg_breaks[loopcounter].mask) != reg_breaks[loopcounter].value)
                     continue;
                  breakpoint = BRK_REGWRITEVAL;
                  }
               else
                  breakpoint = BRK_REGISTER;
               noexecute = TRUE;
               break;
               }
            }
#ifdef HAS_IRP
      filenum_temp2 = xlate_regs[(WORD)regs[FSR] + (((WORD)regs[STATUS] & STATUS_IRP) << 1)];
#else
      filenum_temp2 = xlate_regs[(WORD)regs[FSR] & FSR_MASK];
#endif  /* HAS_IRP */
      }
   if (num_reg_breakpoints)
#ifdef SLOW_REGBREAK_CHECKS
      if (filenum_temp2 != filenum_temp)  /* if we haven't checked this already */
#endif  /* SLOW_REGBREAK_CHECKS */
         for (loopcounter = 0; loopcounter < num_reg_breakpoints; loopcounter++)
            {
            if ((reg_breaks[loopcounter].type & REGBREAK_WRITE)
                     && (reg_breaks[loopcounter].low <= filenum_temp2)
                     && (reg_breaks[loopcounter].high >= filenum_temp2))
               {
               if (reg_breaks[loopcounter].have_value)
                  {
                  if ((regval & reg_breaks[loopcounter].mask) != reg_breaks[loopcounter].value)
                     continue;
                  breakpoint = BRK_REGWRITEVAL;
                  }
               else
                  breakpoint = BRK_REGISTER;
               noexecute = TRUE;
               break;
               }
            }
   if (!noexecute)  /* do not use variable breakpoint, do not confuse with user hotkey */
      (*writeregs[filenum_temp2])();
   }

/*
 *  Note: the functions below this point are designed to be called from
 *        inside the interrupt 9 keyboard handler take_int9().  Thus, they
 *        make minimal use of the stack.
 */

void update_analog_value(val,mode,port,bit)
   WORD *val;
   WORD mode;   /* 4=decrease, 3=increase, 2=toggle, 1=set, 0=reset, OTHERWISE IGNORE */
   WORD port;   /* 0 = A, 1 = B, ... */
   WORD bit;    /* bit number 0 .. 7 */
   {
   if (mode == 2)
      *val ^= 0xffff;
   else
      if (mode == 1)
         *val = 0xffff;
      else
         if (mode == 3)
            {
            if (*val < 0xff00)
               *val += 0x0100;
            else
               *val = 0xffff;
            }
         else
            if (mode == 4)
               {
               if (*val > 0x0100)
                  *val -= 0x0100;
               else
                  *val = 0;
               }
            else
               if (mode == 0)
                  *val = 0x0000;
   if (input_ports[port] & bittable[bit])  /* if ON */
      {
      if (analog_ports[port][bit] < SCHMITT_FALSE_LEVEL)
         input_ports[port] &= ~bittable[bit];
      }
   else
      {
      if (analog_ports[port][bit] > SCHMITT_TRUE_LEVEL)
         input_ports[port] |= bittable[bit];
      }
   }

#ifdef HAS_IOC
   #ifdef PICTYPE_12F675
      void check_ioc()
         {
         if ((last_porta_in ^ input_ports[0])  /* if port status has changed */
                    & regs[IOC]                /* and IOC is set */
                    & regs[TRISA]              /* and pin is an input */
                    & adc_porta_masks[regs[ANSEL]&ADC_CONFIG_MASK]  /* and not assigned to ADC */
                    & cmcon_porta_masks[regs[CMCON]&CMCON_CONFIG_MASK])  /* and not assigned to comparitor */
            regs[INTCON] |= GPIF;  /* set interrupt-on-change */
         }
   #endif  /* PICTYPE_12F675 */
#endif  /* HAS_IOC */

void gpio_bit0(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][0],mode,0,0);
   }

void gpio_bit1(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][1],mode,0,1);
   }

void gpio_bit2(mode)  /* also T0CKI */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][2],mode,0,2);
   /*
    *  Note:  I'm going to fiddle with bit positions here, so that
    *         last_t0cki bit 2 is moved to the T0SE position (bit 4).  This
    *         makes the code "cleaner".
    */
   if ((!sleepmode)                 /* TIMER0 does not operate in sleep mode */
           && (!tmr0_inhibit)       /* and not inhibited */
           && (regs[OPTION] & T0CS))   /* if Timer 0 based on T0CKI transition */
      {
      if (((regs[OPTION] & T0SE) == (last_t0cki & T0SE))  /* if last was correct high/low state */
               && ((input_ports[0] & BIT2) != ((last_t0cki >> 2) & BIT2)))  /* and this is a transition */
         {
         if (regs[OPTION] & PSA)  /* if prescale assigned to WDT */
            regs[TMR0]++;
         else
            {
            if (++tmr0_prescale_counter >= tmr0_prescale)
               {
               regs[TMR0]++;
               tmr0_prescale_counter = 0;
               }
            }
         }
      }
   last_t0cki = input_ports[0] << 2;  /* setup for next edge detect */
   }

void gpio_bit3(mode)  /* also MCLR */
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][3],mode,0,3);
   if (configuration & CONFIG_MCLRE)
      if (!(input_ports[0] & BIT3))  /* if LOW */
         do_mclr_reset = TRUE;
   }

void gpio_bit4(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][4],mode,0,4);
   }

void gpio_bit5(mode)
   WORD mode;   /* 2=toggle, 1=set, 0=reset */
   {
   update_analog_value(&analog_ports[0][5],mode,0,5);
   }

void empty_port(){}   /* something to put a pointer to */

void (*portbitfns[NUM_BYTE_PORTS*8])() =
   {
   gpio_bit0,
   gpio_bit1,
   gpio_bit2,
   gpio_bit3,
   gpio_bit4,
   gpio_bit5,
   empty_port,   /* bit 6 */
   empty_port    /* bit 7 */
   };
