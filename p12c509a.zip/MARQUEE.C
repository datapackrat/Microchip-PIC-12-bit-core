/*
 *  Hi Tech PIC C compiler, V8.02pl1
 */
#include <pic.h>

__CONFIG(WDTDIS & INTRC);

/* Xtal frequency */
#define ON  1
#define OFF 0

/* #define DISPLAY_VIA_LEVELS */  /* this doesn't look very good, but it's available... */
#define DISPLAY_RED_ON_GREEN

#define COLS_PER_CHAR 5

const char charset[27][COLS_PER_CHAR] =
#include "5x5.h"

#define STD_MSG_LEN 15
const char std_message[STD_MSG_LEN+1] = "Hello World!   ";
                                      /* 0123456789abcdef */
char message_byte;
char message_index;
char char_index;
char message_len;
char next_tmr0;
char last_tmr0;

char get_msg_byte()
   {
   if ((message_byte = std_message[message_index]) <= 'Z')
      message_byte += 'a' - 'A';
   if ((message_byte >= 'a') && (message_byte <= 'z'))
      message_byte -= 'a' - 1;
   else
      message_byte = 0;  /* a space */
   }

main()
   {
   TMR0 = 0;
   OPTION = 0b11000111;
           /* ..0..... = T0CS, internal instruction cycle count (CLKOUT) */
           /* ...0.... = T0SE, don't care for T0CS=0 */
           /* ....0... = PSA, prescalar assiged to TMR0 */
           /* .....111 = Prescalar is 256:1 */
   get_msg_byte();
   message_len = STD_MSG_LEN;
#ifdef DISPLAY_VIA_LEVELS
   TRIS = 0;  /* all bits are outputs */
#endif
   for ( ; ; )
      {
      if (last_tmr0 > (next_tmr0 = TMR0))  /* TMR0 rollover */
         {
#ifdef DISPLAY_VIA_LEVELS
         GPIO = ~charset[message_byte][char_index];
#else
   #ifdef DISPLAY_RED_ON_GREEN
         TRIS = ~charset[message_byte][char_index];
   #else
         TRIS = charset[message_byte][char_index];
   #endif
#endif
         if (++char_index == COLS_PER_CHAR)
            {
            char_index = 0;
            if (++message_index == message_len)
               message_index = 0;
            get_msg_byte();
            }
         }
      last_tmr0 = next_tmr0;
      }  /* for ( ; ; ) */
   }  /* main() */
