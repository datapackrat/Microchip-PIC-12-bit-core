#ifdef NEVERDEF
/****************************************************************************
 ****************************************************************************
 *                                                                          *
 *   WARNING!                                                               *
 *                                                                          *
 *   I've discovered a bug in the code optimizer.  A definition like:       *
 *      #define TESTBITS (BIT1|BIT2)                                        *
 *   can produce incorrect code output from the optimizer when TESTBITS     *
 *   is used.                                                               *
 *                                                                          *
 *   Instead, use a definition like:                                        *
 *      #define TESTBITS 0x05  /* (BIT1|BIT2) */                            *
 *   Yes, that's not as "ideal", but it will save a WORLD of problems!      *
 *                                                                          *
 ****************************************************************************
 ****************************************************************************/
#endif

/*
 *  PIC emulator.  12C509A version.
 *  Part 1, break original program in two for compatibility with other PICEMU
 *  flavors.
 *
 *  Copyright (c) 2001-2004 by
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICEMU
 *
 *  PICEMU is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICEMU is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *
 *  Revision history
 *
 *  Date      Comments
 *  --------  ---------------------------------------------
 *  8/xx/01   Original code
 *  11/14/01  Code cleanup for 1st BETA release
 *  1/3/03    Added cli/sti couple to avoid wrong PORT drawings on int9
 *  2/20/04   New commands, add analog inputs
 *  3/15/04   Source code unification for 14-bit core programs.
 */

#include <picemu.h>

WORD memory[MEMORY_SIZE];  /* program memory */

BYTE regs[NUM_REGS+HIDDEN_REGS];

#ifdef EEPROM_SIZE
   BYTE eeprom[EEPROM_SIZE];
#endif  /* EEPROM_SIZE */

#ifdef CORE_14BIT
   BYTE show_regs[NUM_REGS];  /* which regs to display */
#endif  /* CORE_14BIT */
BYTE regval;
            BYTE alignregval_1; /* alignment, keep important vars on a multiple of 4 */
            WORD alignregval_2;
BYTE read_regs();  /* external declaration */

        WORD aligninitial_ports = 0;  /* align the initalized variables */
WORD initial_ports[NUM_BYTE_PORTS][8] =
   {
#ifdef PICTYPE_16F648
   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0xffff, 0x0000, 0x0000
         /* MCLR is multiplexed with A5, and MCLRE in CONFIG is default set */
#else
   #ifdef PICTYPE_12F675
      0x0000, 0x0000, 0x0000, 0xffff, 0x0000, 0x0000, 0x0000, 0x0000
            /* MCLR is multiplexed with A3, and MCLRE in CONFIG is default set */
   #else
      #ifdef PICTYPE_12C509A
         0x0000, 0x0000, 0x0000, 0xffff, 0x0000, 0x0000, 0x0000, 0x0000
          /* MCLR is multiplexed with GP3, and MCLRE in CONFIG is default set */
      #else
         0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0xffff
            /* default to MCLR high (16F84A, 16F877) */
      #endif  /* PICTYPE_12C509A */
   #endif  /* PICTYPE_12F675 */
#endif  /* PICTYPE_16F648 */
#ifdef HAS_PORTB
   ,
   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000
#endif  /* HAS_PORTB */
#ifdef HAS_PORTC
   ,
   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000
#endif  /* HAS_PORTC */
#ifdef HAS_PORTD
   ,
   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000
#endif  /* HAS_PORTD */
#ifdef HAS_PORTE
   ,
   0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000, 0x0000
#endif  /* HAS_PORTE */
   };
BYTE input_ports[NUM_BYTE_PORTS_ALLOCATE];
BYTE port_masks[NUM_BYTE_PORTS_ALLOCATE] =
   {
#ifdef PICTYPE_16F648
   0x3f  /* FOSC2:FOSC0 default is 111: ER oscillator: CLKOUT on RA6,
          * resistor on RA7
          */
#endif  /* PICTYPE_16F648 */
#ifdef PICTYPE_12F675
   0x0f  /* FOSC2:FOSC0 default is 111: RC oscillator: CLKOUT on A4,
          * resistor on A5
          */
#endif  /* PICTYPE_12F675 */
#ifdef PICTYPE_16F877
   0xbf  /* use high bit of PORTA for MCLR */
#endif  /* PICTYPE_16F877 */
#ifdef PICTYPE_16F84A
   0x9f  /* use high bit of PORTA for MCLR */
#endif  /* PICTYPE_16F84A */
#ifdef PICTYPE_12C509A
   0x3f   /* MCLR is on GP3, no need for a separate flag mapped to A7 */
#endif  /* PICTYPE_12C509A */
#ifdef HAS_PORTB
   ,
   #ifdef PICTYPE_16F648
      0xef   /* PGM is multiplexed with B4 via LVP in CONFIG, default is set */
   #else
      0xff
   #endif  /* PICTYPE_16F648 */
#endif  /* HAS_PORTB */
#ifdef HAS_PORTC
   ,
   0xff
#endif  /* HAS_PORTC */
#ifdef HAS_PORTD
   ,
   0xff
#endif  /* HAS_PORTD */
#ifdef HAS_PORTE
   ,
   0x07
#endif  /* HAS_PORTE */
   };
WORD analog_ports[NUM_BYTE_PORTS][8];
/* BYTE port_screen[NUM_BYTE_PORTS_ALLOCATE * 9 * 3 * 2]; */
          /* use _ALLOCATE to keep things a multiple of 4 */
/* BYTE watch_screen[80 * 3 * 2]; */  /* 3 lines of 80 chars/attributes */
struct keypins key_pins[MAX_KEYPINS];
   /* NOTE: Always allocate max number of key_pins, so that the same INT9
    *       code can be used for both 8-pin and larger PICs.
    */

#ifdef ALIGN_STACK_1
   BYTE stack_align_1;
#endif  /* ALIGN_STACK_1 */
#ifdef ALIGN_STACK_2
   WORD stack_align_2;
#endif  /* ALIGN_STACK_2 */

WORD stack[STACK_SIZE];
WORD stack_ptr = 0;
WORD stack_depth = 0;
WORD max_stack_depth = 0;
            WORD alignmax_stack_depth = 0;

WORD opcode;        /* opcode we're working on */
            WORD alignopcode;
WORD ip;            /* instruction pointer */
            WORD alignip;
BYTE w;             /* Working register */
            BYTE alignw1;
            WORD alignw2;
WORD statushold;    /* hold for status flags */
            /* BYTE alignstatushold1; */
            WORD alignstatushold2;
WORD filenum;       /* index into regs */
            WORD alignfilenum;
WORD filenum_temp;  /* bank select bits + filenum */
            WORD alignfilenum_temp;
WORD filenum_temp2; /* filenum_temp via xlat_regs[] */
            WORD alignfilenum_temp2;
WORD dest;          /* 1=destination is F (register File) 0=destination is W */
            WORD aligndest;
WORD breakpoint;    /* !0, have breakpoint, else FALSE */
            WORD alignbreakpoint;
WORD noexecute;     /* !0, do not execute instruction, else FALSE */
            WORD alignnoexecute;
WORD chkstack;      /* !0, breakpoint on stack overflow/underflow */
            WORD alignchkstack;
WORD chkwatchdog;   /* !0, breakpoint on watchdog expired */
            WORD alignchkwatchdog;
WORD sleepmode;     /* TRUE if sleeping, else FALSE */
            WORD alignsleepmode;
WORD port_video_addr;    /* for port display */
            WORD alignport_video_addr;
WORD watch_video_addr;   /* for watch display */
            WORD alignwatch_video_addr;
WORD last_t0cki;    /* for T0CKI edge detection */
            WORD alignlast_t0cki;
WORD last_wakepins; /* for wake on pin change */
            WORD alignlast_wakepins;
BYTE last_porta_in; /* for IOC (P12F675) */
            BYTE alignlast_porta_in_1;
            WORD alignlast_porta_in_2;

#ifdef CORE_14BIT
   WORD interrupt_pending;  /* need to do an interrupt */
            WORD aligninterrupt_pending;
   WORD noticed_interrupt;  /* just set interrupt_pending once */
            WORD alignnoticed_interrupt;
   BYTE last_intpin;   /* for interrupt on rising/falling signal on INT pin */
            BYTE alignlast_intpin_1;
            WORD alignlast_intpin_2;
#endif  /* CORE_14BIT */

#ifdef HAS_CMCON
   BYTE last_cout;     /* for comparitor change interrupt */
            BYTE alignlast_cout_1;
            WORD alignlast_cout_2;
#endif  /* HAS_CMCON */

#ifdef HAS_PORTB
   BYTE last_portb;    /* for port change interrupt */
            BYTE alignlast_portb_1;
            WORD alignlast_portb_2;
   BYTE last_portb_in; /* for INT pin edge detect */
            BYTE alignlast_portb_in_1;
            WORD alignlast_portb_in_2;
#endif  /* HAS_PORTB */

#ifdef HAS_CCP
   BYTE last_ccp1;     /* for CCP1 edge detection */
            BYTE alignlast_ccp1_1;
            WORD alignlast_ccp1_2;
   BYTE ccp1_count;    /* for CCP1 4th rising edge / 16th rising edge detection */
            BYTE alignccp1_count_1;
            WORD alignccp1_count_2;
   WORD ccp1_mode;
            WORD alignccp1_mode;
   WORD ccp1_fn;
            WORD alignccp1_fn;
   WORD ccp1_dutycycle; /* PWM duty cycle */
            WORD alignccp1_dutycycle;
   WORD ccp1_pwm_high;  /* only reset it once */
            WORD alignccp1_pwm_high;
   WORD tmr1_needs_reset;  /* CCPx special event */
            WORD aligntmr1_needs_reset;
   #ifdef HAS_CCP2
      BYTE last_ccp2;     /* for CCP2 edge detection */
            BYTE alignlast_ccp2_1;
            WORD alignlast_ccp2_2;
      BYTE ccp2_count;    /* for CCP2 4th rising edge / 16th rising edge detection */
            BYTE alignccp2_count_1;
            WORD alignccp2_count_2;
      WORD ccp2_mode;
            WORD alignccp2_mode;
      WORD ccp2_fn;
            WORD alignccp2_fn;
      WORD ccp2_dutycycle; /* PWM compare value */
            WORD alignccp2_dutycycle;
      WORD ccp2_pwm_high;  /* only reset it once */
            WORD alignccp2_pwm_high;
   #endif  /* HAS_CCP2 */
#endif  /* HAS_CCP */

#ifdef HAS_TMR1
   BYTE last_t1cki;    /* for T1CKI edge detection */
            BYTE alignlast_t1cki_1;
            WORD alignlast_t1cki_2;
   BYTE t1cki_edge;    /* flag: need a falling edge befor counting rising edge */
            BYTE alignt1cki_edge_1;
            WORD alignt1cki_edge_2;
   BYTE last_t1osi;    /* for T1OSI edge detection */
            BYTE alignlast_t1osi_1;
            WORD alignlast_t1osi_2;
   BYTE t1osi_edge;    /* flag: need a falling edge before counting rising edge */
            BYTE alignt1osi_edge_1;
            WORD alignt1osi_edge_2;
   WORD tmr1_prescale;
            WORD aligntmr1_prescale;
   WORD tmr1_prescale_counter;
            WORD aligntmr1_prescale_counter;
   WORD tmr1_inhibit;     /* TMR1 update is inhibited for one instruction cycle
                           * after write to TMR1L or TMR1H.  This is not in the
                           * documentation.
                           */
            WORD aligntmr1_inhibit;
#endif  /* HAS_TMR1 */

BYTE temp1;         /* useful to have around */
            BYTE aligntemp1_1;
            WORD aligntemp1_2;
WORD wtemp3;        /* useful to have around */
            WORD alignwtemp3;
BYTE temp2;         /* useful to have around */
            BYTE aligntemp2_1;
            WORD aligntemp2_2;
WORD wtemp4;        /* useful to have around */
            WORD alignwtemp4;

#ifdef HAS_TMR2
   WORD tmr2_pwm_dutycycle;
            WORD aligntmr2_pwm_dutycycle;
   WORD tmr2_prescale;
            WORD aligntmr2_prescale;
   WORD tmr2_prescale_counter;
            WORD aligntmr2_prescale_counter;
   WORD tmr2_postscale_counter;
            WORD aligntmr2_postscale_counter;
   WORD tmr2_inhibit;                /* inhibit update of TIMER2 */
            WORD aligntmr2_inhibit;
   WORD tmr2_prescale_pwm_bitshift;
            WORD aligntmr2_prescale_pwm_bitshift;
   WORD tmr2_prescale_table[4] =
      {
      1,
      4,
      16,
      16
      };
   WORD tmr2_prescale_pwm_table[4] =
      {
      4,      /* 4-bit shift will give us 0's for lowbits */
      0,      /* use bottom bits */
      2,      /* use top bits */
      2
      };
#endif  /* HAS_TMR2 */

#ifdef PICTYPE_12F675
   DWORD frequency =  4000000; /*  4Mhz */   /* CPU frequency (use for USART, ADC, and throttling) */
#else
   #ifdef PICTYPE_12C509A
      DWORD frequency = 4000000;  /* 4Mhz */  /* CPU frequency: use for throttling */
   #else
      DWORD frequency = 20000000; /* 20Mhz */   /* CPU frequency (use for USART, ADC, and throttling) */
   #endif  /* PICTYPE_12C509A */
#endif  /* PICTYPE_12F675 */

WORD watchdog;    /* watchdog timer */
            WORD alignwatchdog;
WORD watchdog_enabled;  /* configuration & CONF_WDTE */
            WORD alignwatchdog_enabled;
WORD watchdog_reset_count;  /* reset value for watchdog to give 18ms nominal timer */
            WORD alignwatchdog_reset_count;
WORD do_mclr_reset;   /* do a MCLR reset */
            WORD aligndo_mclr_reset;
WORD tmr0_inhibit;                       /* inhibit update of TMR0 */
            WORD aligntmr0_inhibit;
WORD tmr0_prescale;
            WORD aligntmr0_prescale;
WORD tmr0_prescale_counter;              /* TMR0 / watchdog prescale counter */
            WORD aligntmr0_prescale_counter;

#ifdef HAS_VRCON
   WORD cvref;  /* Compare Voltage Reference */
            WORD aligncvref;
#endif  /* HAS_VRCON */

#ifdef CORE_12BIT
   WORD configuration = 0x1f;  /* 12C509A default */
#else
   WORD configuration = 0x3fff;  /* 16fxxx / 12F675 default */
#endif  /* CORE_12BIT */
            WORD alignconfiguration = 0;

#ifdef HAS_ADC
   WORD adc_delay;     /* if set, we're doing an "ADC conversion" */
   WORD adc_result;
   WORD adc_table[ADC_TABLE_MAXSIZE];
   WORD adc_table_size;
   WORD adc_table_index;
#endif  /* HAS_ADC */

#ifdef EEPROM_SIZE
   /*
    *  Note:  The timing represented by eecon2_state/eecon2_ready is:
    *       <...set BANK bits...>
    *       MOVLW 55   ;need this instr
    *       MOVWF 0D   ;set EECON2, eecon2_state = 3
    *                  ;interpreter loop post-processing, eecon2_state = 2
    *       MOVLW AA   ;need this instr
    *                  ;interpreter loop post-processing, eecon2_state = 1
    *       MOVWF 0D   ;set EECON2, eecon2_ready = 2
    *                  ;interpreter loop post-processing, eecon2_ready = 1
    *       BSF   0C,1 ;start write
    */
   WORD eecon2_state;  /* state of write(s) to EECON2 reg */
            WORD aligneecon2_state;
   WORD eecon2_ready;
            WORD aligneecon2_ready;
   WORD eeprom_delay;
            WORD aligneeprom_delay;
#endif  /* EEPROM_SIZE */

WORD num_watch_regs;
            WORD alignnumwatchregs;
WORD watch_regs_delay;
            WORD alignwatchregsdelay;
WORD watchregs[NUM_WATCHREGS];

WORD io_processing_waiting;
            WORD aligniopwaiting;
WORD readusestris;
            WORD alignreadusestris;

DWORD instructioncount[2];   /* fake a 64-bit integer */
DWORD breakcount[2];  /* fake a 64-bit integer */
DWORD stimulus_delay[2];  /* fake a 64-bit int */

WORD timingcount, timingtemp;
       /* did this instruction occupy 1 cycle, or 2 (changed IP, therefore
        * instruction in prefetch executed as NOP's)
        */
WORD throttle, throttlecount;      /* allow variable execution speed */

WORD unasm_ip = RESET_IP;   /* default disassembly address */
WORD asm_ip = 0;            /* default assembly address */
            WORD alignasm_ip = 0;

#ifdef PICTYPE_12C509A
   WORD wakemask = WAKEPINS_NO_GP3;        /* if MCLR enabled WAKEPINS_NO_GP3 else WAKEPINS */
            WORD alignwakemask = 0;
#endif  /* PICTYPE_12C509A */

WORD bittable[8] =  /* bit mask, indexed by bit number */
                    /* also used for prescalar */
   {
   BIT0,
   BIT1,
   BIT2,
   BIT3,
   BIT4,
   BIT5,
   BIT6,
   BIT7
   };

BYTE instr_str[64];  /* disassembled instruction */

DWORD total_ic[2];  /* count of instructions executed */  /* fake a 64-bit int */
WORD wherequeue[WHERE_SIZE+1];  /* queue of addresses for where? */
WORD whereptr;  /* pointer into "where was I?" queue */
            WORD alignwhereptr;
DWORD stopwatchcount[2];  /* "stopwatch" count */  /* fake a 64-bit integer */
DWORD stopwatch_reset_time[2];
DWORD stopwatch_startticks;

WORD oscope_lines;
WORD oscope_maxwidth;
WORD oscope_in;  /* IN index to oscope_data[] */
WORD oscope_out; /* OUT index to oscope_data[] */
DWORD oscope_count;
DWORD oscope_delay;
WORD oscope_logical;
WORD oscope_video_addr;    /* for oscope display */
/*            WORD alignoscope_video_addr; */
/* WORD oscope_data[MAX_OSCOPE_LINES][MAX_SCREEN_WIDTH]; */

struct stim stimulus[MAX_STIMULUS_SIZE];

#ifdef USE_ADDRLIST
   WORD addrlist_seg;  /* if non-zero, MEMORY_SIZE WORDS of allowed addresses */
   WORD addrlist;   /* if TRUE, we have an addrlist to process */
   WORD have_addrlist;
               WORD alignaddrlist;
#endif  /* USE_ADDRLIST */

    /* here ends the DWORD aligned variables */

WORD i2c_bytecount;
WORD i2c_bufindex;
BYTE i2c_databyte;
BYTE i2c_mode;
WORD scl_bitmask;
WORD i2c_hdr_size;
WORD i2c_addr_mask;
WORD i2c_address;
WORD i2c_page_mask;
WORD i2c_page_max;   /* i2c_page_max = i2c_hdr_size; if (i2c_type != 1) i2c_page_max += i2c_page_mask + 1; */
WORD i2c_seg;
   /* NOTE: Since I don't have enough RAM space in 64K to do an I2C EEPROM,
    *       and an EEPROM is something that takes time to access, I'm going
    *       to put it in "free" memory above PICEMU and access it manually.
    *
    *       If there isn't enough RAM for the I2C EEPROM, i2c_seg will
    *       be 0.
    */

WORD i2c_type;
BYTE i2c_buf[I2C_BUFSIZE];
WORD last_sda;
WORD last_sda_tris;
WORD last_scl;
WORD scl_pin;
WORD scl_pinmask;
WORD scl_port;
WORD sda_pin;
WORD sda_pinmask;
WORD sda_port;

/*
WORD oscope_ports[MAX_OSCOPE_LINES];
WORD oscope_pins[MAX_OSCOPE_LINES];
WORD oscope_pinmasks[MAX_OSCOPE_LINES];
BYTE oscope_lastport[MAX_OSCOPE_LINES];
BYTE oscope_lasttris[MAX_OSCOPE_LINES];
*/

BYTE stim_pinmasks[NUM_BYTE_PORTS_ALLOCATE];
WORD num_stimulus;
WORD stimulus_index;  /* which stimulus to apply */
WORD periodic_stim;
struct stim *pstim;

BYTE tempstr[STRING_SIZE];


/*  Note:  Even though these are only used for hardware UART emulation,
 *         define them anyway so that only 1 version of take_int9() is
 *         needed.
 */
WORD commport = 1;  /* NON-ZERO!  if commport is used, will be set to 0 by PSHELL.C */
BYTE uart_in_queue[UART_QUEUE_SIZE+8];
WORD uart_in_queue_head;
WORD uart_in_queue_tail;

#ifdef HAS_UART
   BYTE old_uart_setup[8];

   WORD tsr_hold;          /* buffer TX output */
   WORD tsr_hold_available; /* data is available in tsr_hold */
   WORD trmt_hold_delay_count;  /* instruction cycles need to TX a byte */
   WORD trmt_hold_delay;   /* delay counter for TX output */
   WORD tsr_hold_delay;    /* instruction cycles before sending TRMT to send_byte() */
      /*
       * NOTE: This needs to be done for correct serial emulation.  Since
       *       TXREG moves it's data into into the TSR (transmit shift reg),
       *       and then immediately becomes available (i.e. sets TXIF) for
       *       new TX data, we can have a situation like this:
       *          ...
       *          while (outbuf_tail != outbuf_head)
       *             {
       *             if (TXIF)
       *                TXREG = outbuf[outbuf_tail++];
       *             }
       *          TXIE = 0;  //turn off TX interrupts
       *          TXEN = 0;  //turn off TSR (multidrop protocol)
       *          ...
       *       Why is this a problem?  Well, since TXIF is set when TXREG
       *       is moved into the TSR, we immediately move new data into TXREG,
       *       then notice our buffer is empty, so we turn off both TXIE
       *       (TX interrupt enable) and TXEN (turn off the TSR).  But this
       *       is done so fast that the PIC doesn't have time to send the data
       *       in the TSR, let alone the new data in TXREG.  So the last 2
       *       serial out chars are "dropped".  And since the PC serial port
       *       doesn't support turning off the TX, I'm going to fake it by not
       *       sending the character until half the char would have left the
       *       TSR, so that that the correct number of characters are dropped.
       *       (Though I can't simulate turning off the TSR in the middle of
       *       a char, so I can't simulate the framing error that would cause.)
       *
       *       Yes, the above code fragment could be fixed by:
       *          ...
       *          TXIE = 0;      // turn off TX interrupts
       *          while (!TRMT)  // wait until TSR empty
       *             ;
       *          TXEN = 0;     // turn off TSR (multidrop protocol)
       *          ...
       *       but the job of a interpreter/debugger is to let you find
       *       your errors, not do it right in spite of your errors.
       */
   WORD tx_data_available;  /* TXREG has fresh data */
   WORD tx_port_available;  /* TXREG ready to receive data */
   WORD rc_data_available;  /* RCREG has fresh data */
   WORD tx_int_delay = 0;   /* default: no delay */
   WORD tx_int_delay_counter = 0;
   WORD winnt = FALSE;
    /*   I'd better explain why I need to detect NT for serial I/O:
     *         MICRO$QUISH SUCKS!
     *
     *   Or, to be more explicit:  NT is trying to "protect" the hardware,
     *   so all I/O is virtualized.  This is a *SLOW* process.  When I do
     *   an outp() to send the char, it takes so long that, on a 600Mhz PIII,
     *   a basic interrupt driven serial I/O loop does not have time to do
     *   *ANYTHING* but the interrupt process, over and over.
     *
     *   So, I have to delay presenting the TX IRQ for a while, so that the
     *   rest of the program has a chance to run before servicing the next
     *   TX interrupt.
     */
   /* WORD junk_align_z = 0; */
#endif  /* HAS_UART */

WORD swap_screens = FALSE;  /* swap screens for UART/SoftUart */
WORD screen_rowofs;
WORD screen_colofs;
            /* NOTE: screen_rowofs, screen_colofs are offsets into memory, not
             *       "row", and "col" numbers
             */
WORD hex_uart_screen;  /* TRUE or FALSE */
WORD hex_kbd_hold;     /* if hex_uart_screen, send hex from keyboard */
BYTE uart_screen[SCREEN_ROWS * SCREEN_COLS * 2];  /* *2 for char/attribute */
WORD uart_screen_maxrow;  /* max row to use for UART/SoftUART screen */
WORD uart_screen_maxrowofs;  /* max ofs to use for UART/SoftUART screen */
            /* NOTE: uart_screen_maxrowofs is an offset into memory, not
             *       a "row" number
             */

WORD num_reg_breakpoints;
struct regbreaks reg_breaks[MAX_REG_BREAKS];

WORD num_mem_breakpoints;
struct membreaks mem_breaks[MAX_MEM_BREAKS];

/*  Note:  Define these in the Pxxx.C files to make sure they are at least
 *         WORD aligned.
 */

/* TX:  transmission from PIC --> USER */
/*  Note: su_txdata will start at 0, be right shifted before a new bit is
 *        put in the top of the word.  Thus, the received data will look like
 *        <stop bits><parity (if any)><data bits><start bit><0's>
 */
WORD su_txenable;    /* if 0, we are doing PIC --> USER bitbanging */
WORD su_txbaud;      /* baudrate, 110 to 57600 (max of frequency/16) */
WORD su_txport;      /* PORT used for TX pin */
WORD su_txpin;       /* bit in PORT for TX pin */
WORD su_txbittiming; /* instructions per bit */
WORD su_txcount;     /* count of bits received from PIC */
WORD su_txtiming;    /* if != 0, inst. count until next bit receive */
WORD su_txdatabits;  /* number of data bits we're expecting, 7 or 8 */
WORD su_txparity;    /* 'E'ven, 'N'one, or 'O'dd */
WORD su_txstopbits;  /* number of stop bits we're expecting, 1 or 2 */
WORD su_txtotalbits; /* total bits: 1 (start bit) + databits + stop bits + parity (if any) */
WORD su_txstopmask;  /* 0x8000 or 0xc000 for 1 or 2 stop bits (top of receive word) */
WORD su_txframemask; /* su_txstopmask | (1 << (16-txtotalbits)), check start bit for 0 as well as stop bits */
WORD su_txdatamask;  /* mask for 7/8 bit data: 0x7f or 0xff */
WORD su_txdatashift; /* bits to shift data to put it at the bottom of the low byte */
WORD su_txdata;      /* data we've received */
WORD su_txlastbit;   /* previous state of our TX pin, for start of data detection */
WORD su_txbitmask;   /* bittable[su_txpin] */
WORD su_txinvert;    /* 0x00 (normal) or 0xff (inverted) logic levels */
WORD doing_portwrite;  /* flag for io_processing and su_tx stuff */
WORD doing_portread;   /* flag: this value came from an I/O port
                        *       (mostly for BSF / BCF)
                        */

/* RX:  transmission from USER --> PIC */
/*  Note: su_rxdata will start at contain the formatted bit string.  Bits
 *        will be read from the bottom of the word, which will then be
 *        shifted right.  Thus, the data to send will look like:
 *        <0's><stop bits><parity (if any)><data bits><start bit>
 */
WORD su_rxenable;    /* if 0, we are doing USER --> PIC bitbanging */
WORD su_rxbaud;      /* baudrate, 110 to 57600 (max of frequency/16) */
WORD su_rxport;      /* PORT used for TX pin */
WORD su_rxpin;       /* bit in PORT for TX pin */
WORD su_rxbittiming; /* instructions per bit */
WORD su_rxcount;     /* count of bits received from PIC */
WORD su_rxtiming;    /* if != 0, inst. count until next bit receive */
WORD su_rxdatabits;  /* number of data bits we're expecting, 7 or 8 */
WORD su_rxparity;    /* 'E'ven, 'N'one, or 'O'dd */
WORD su_rxstopbits;  /* number of stop bits we're expecting, 1 or 2 */
WORD su_rxtotalbits; /* total bits: 1 (start bit) + databits + stop bits + parity (if any) */
WORD su_rxstopmask;  /* 0x01 or 0x03 (1 or 2 stop bits) << (start+databits+paritybits) */
WORD su_rxdatamask;  /* mask for 7/8 bit data: 0x7f or 0xff */
WORD su_rxdata;      /* data we've received */
WORD su_rxbitmask;   /* bittable[su_rxpin] */
WORD su_rxinvert;    /* 0x00 (normal) or 0xffff (inverted) logic levels */
BYTE su_rx_in_queue[UART_QUEUE_SIZE+8];
WORD su_rx_in_queue_head;
WORD su_rx_in_queue_tail;

extern WORD show_ports;
extern WORD have_tickcount;  /* for timed run */
extern DWORD startticks;
extern DWORD stopwatchticks;

#ifdef PICTYPE_12F675
   extern BYTE adc_porta_masks[ADC_CONFIG_MASK+1];  /* indexed by ANSEL & ADC_CONFIG_MASK */
   extern BYTE cmcon_porta_masks[CMCON_CONFIG_MASK+1];  /* indexed by CMCON & CMCON_CONFIG_MASK */
      /* Need these for "interrupt on pin change */
#endif  /* PICTYPE_12F675 */

extern void (*portbitfns[NUM_BYTE_PORTS*8])();

main(argc,argv)
   WORD argc;
   BYTE *argv[];
   {
#ifdef M_1B
#asm
   nop        ;code alignment
#endasm
#endif  /* M_1B */

#ifdef M_2B
#asm
   nop        ;code alignment
   nop        ;code alignment
#endasm
#endif  /* M_2B */

#ifdef M_4B
#asm
   nop        ;code alignment
   nop        ;code alignment
   nop        ;code alignment
   nop        ;code alignment
#endasm
#endif  /* M_4B */

#ifdef M_8B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
#endasm
#endif  /* M_8B */

#ifdef M_16B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
   nop        ;code alignment  9
   nop        ;code alignment  10
   nop        ;code alignment  11
   nop        ;code alignment  12
   nop        ;code alignment  13
   nop        ;code alignment  14
   nop        ;code alignment  15
   nop        ;code alignment  16
#endasm
#endif  /* M_16B */

#ifdef M_32B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
   nop        ;code alignment  9
   nop        ;code alignment  10
   nop        ;code alignment  11
   nop        ;code alignment  12
   nop        ;code alignment  13
   nop        ;code alignment  14
   nop        ;code alignment  15
   nop        ;code alignment  16
   nop        ;code alignment  17
   nop        ;code alignment  18
   nop        ;code alignment  19
   nop        ;code alignment  20
   nop        ;code alignment  21
   nop        ;code alignment  22
   nop        ;code alignment  23
   nop        ;code alignment  24
   nop        ;code alignment  25
   nop        ;code alignment  26
   nop        ;code alignment  27
   nop        ;code alignment  28
   nop        ;code alignment  29
   nop        ;code alignment  30
   nop        ;code alignment  31
   nop        ;code alignment  32
#endasm
#endif  /* M_32B */

#ifdef HAS_UART
   check_winnt();  /* set winnt flag */
#endif  /* HAS_UART */
   setup();  /* do any initial processing necessary */
   menu(argc,argv);   /* emulation under user control */
   cleanup();  /* any exit processing necessary */
   }

BYTE getfile()  /* assumes filenum contains index into register file */
   {
   filenum_temp = (regs[FSR] & FSR_MEMORYPAGE_BITMASK) + filenum;
   return(read_regs());
   }

void setfile(val) /* assumes filenum contains index into register file */
   WORD val;
   {
   if (!noexecute)
      {
      regval = val;  /* set global for easy access */
      filenum_temp = (regs[FSR] & FSR_MEMORYPAGE_BITMASK) + filenum;
      write_regs();
      }
   }

void setreg(fn,val)
   WORD fn, val;
   {
   WORD save;

   filenum_temp = fn;
   regval = val;
   save = num_reg_breakpoints;
   num_reg_breakpoints = 0;  /* don't use reg breakpoints for this */
   write_regs();
   num_reg_breakpoints = save; /* reset reg breakpoints */
   }

void push_ip()
   {
   if ((chkstack) && (stack_depth >= STACK_SIZE))
      {
      breakpoint = BRK_STACKOVF;
      noexecute = TRUE;
      }
   else
      {
      stack[1] = stack[0];
      stack[0] = ip;
      stack_depth++;
      if (stack_depth > max_stack_depth)
         max_stack_depth = stack_depth;
      }
   }

void pop_ip()
   {
   if ((chkstack) && (stack_depth == 0))
      {
      breakpoint = BRK_STACKUNDF;
      noexecute = TRUE;
      }
   else
      {
      ip = stack[0];
      stack[0] = stack[1];
      timingcount++;  /* NOPs now in prefetch queue */
      stack_depth--;
      if (stack_depth > max_stack_depth)
         max_stack_depth = stack_depth;
             /* NOTE: since stack_depth and max_stack_depth are UNSIGNED,
              * a stack_depth of -1 is 0xffff, which is > than any current
              * max_stack_depth so this DOES note stack underflow.
              */
      }
   }

void calcflags_add(first,second,result)
   WORD first, second, result;
   {
   statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get current STATUS flags */
   if (result)
      statushold &= ~STATUS_Z;
   else
      statushold |= STATUS_Z;
   if (((first & 0x0f) + (second & 0x0f)) & 0xf0)  /* if Aux Carry */
      statushold |= STATUS_DC;
   else
      statushold &= ~STATUS_DC;
   if ((first+second) & 0xff00)  /* if Carry */
      statushold |= STATUS_C;
   else
      statushold &= ~STATUS_C;
   }

void calcflags_sub(first,second,result)
   WORD first, second, result;
   {
   statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get current STATUS flags */
   if (result)
      statushold &= ~STATUS_Z;
   else
      statushold |= STATUS_Z;
   if (((first & 0x0f) - (second & 0x0f)) & 0xf0)  /* if Aux Carry */
      statushold &= ~STATUS_DC;
   else
      statushold |= STATUS_DC;
   if ((first-second) & 0xff00)  /* if Carry */
      statushold &= ~STATUS_C;
   else
      statushold |= STATUS_C;
   }

void controls_12bit()
      /* 12bit:    000000 xx xxxx = NOP/OPTION/SLEEP/CLRWDT/TRIS/MOVWF
       * filenum = ...... .f ffff
       * dest    = ...... d. ....
       * NOP     = 000000 00 0000
       * OPTION  = 000000 00 0010
       * SLEEP   = 000000 00 0011
       * CLRWDT  = 000000 00 0100
       * TRIS    = 000000 00 0110  <actually, 000000 00 0fff, but only fff=6 valid>
       * MOVWF   = 000000 1f ffff
       *   <unused opcodes will default to NOP>
       */
   {
   BYTE last_option, alignment;

   if (dest)  /* if dest set, this must be MOVWF */
      setfile(w);
   else
      {
      switch (filenum)
         {
         case 2:  /* OPTION */
            last_option = regs[OPTION];
            regs[OPTION] = w;
            tmr0_prescale = bittable[regs[OPTION] & OPTION_PRESCALE_BITS];
            if (!(regs[OPTION] & PSA))  /* if prescale assigned to TMR0 */
               tmr0_prescale <<= 1;  /* prescale is 2 .. 256 */
            if ((last_option & T0CS) && (!(regs[OPTION] & T0CS)))  /* if just turned T0CS on */
               tmr0_inhibit = 3;  /* inhibit TMR0 update for 2 instruction cycles */
                                  /* Yup, I mean 3! */
            break;
         case 3:  /* SLEEP */
            regs[STATUS] = regs[STATUS] | STATUS_TO & ~STATUS_PD;
               /* Note:  the writeregs[]() functions do not allow us to
                *        change the TO and PD bits in the status, so we have
                *        to do it directly.  Thus, we can't do a breakpoint
                *        on STATUS for this instruction.
                */
            sleepmode = TRUE;
            watchdog = watchdog_reset_count;
            if (regs[OPTION] & PSA)  /* if prescalar assigned to WDT */
               tmr0_prescale_counter = 0;
            break;
         case 4:  /* CLRWDT */
            regs[STATUS] |= STATUS_TO | STATUS_PD;
               /* Note:  the writeregs[]() functions do not allow us to
                *        change the TO and PD bits in the status, so we have
                *        to do it directly.  Thus, we can't do a breakpoint
                *        on STATUS for this instruction.
                */
            watchdog = watchdog_reset_count;
            if (regs[OPTION] & PSA)  /* if prescalar assigned to WDT */
               tmr0_prescale_counter = 0;
            break;
         case 6:  /* TRIS */
            regs[TRISA] = w & 0x3f;  /* set TRIS register */
            io_processing();
            break;
         }
      }  /* if (dest) ... else */
   }

void clr_12bit()
      /* CLRW / CLRF = 000001 xx xxxx = CLRW / CLRF
       * filenum     = ...... .x xxxx
       * dest        = ...... x. ....
       * CLRW        = 000001 00 0000 <actually, 000001 0x xxxx>
       * CLRF        = 000001 1f ffff
       */
   {
   statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
   if (!dest)  /* if W is destination */
      w = 0;  /* clear w */
   else
      setfile(0);  /* set "filenum" to 0, set Z */
   if (!noexecute)
      regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
   }

void subwf()            /* 000010 df ffff = SUBWF */
   {
   temp1 = getfile();
   if (!noexecute)
      {
      temp2 = temp1 - w;
      calcflags_sub(temp1,w,temp2);
      if (!dest)  /* if W is destination */
         w = temp2;
      else
         setfile(temp2);
      regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | statushold;
      }
   }

void decf()             /* 000011 df ffff = DECF */
   {
   temp1 = getfile() - 1;
   if (!noexecute)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (!dest)  /* if W is destination */
         w = temp1;
      else
         setfile(temp1);
      if (temp1)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      }
   }

void iorwf()            /* 000100 df ffff = IORWF */
   {
   temp1 = getfile() | w;
   if (!noexecute)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (!dest)  /* if W is destination */
         w = temp1;
      else
         setfile(temp1);
      if (temp1)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      }
   }

void andwf()            /* 000101 df ffff = ANDWF */
   {
   temp1 = getfile() & w;
   if (!noexecute)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (!dest)  /* if W is destination */
         w = temp1;
      else
         setfile(temp1);
      if (temp1)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      }
   }

void xorwf()            /* 000110 df ffff = XORWF */
   {
   temp1 = getfile() ^ w;
   if (!noexecute)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (!dest)  /* if W is destination */
         w = temp1;
      else
         setfile(temp1);
      if (temp1)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      }
   }

void addwf()            /* 000111 df ffff = ADDWF */
   {
   temp1 = getfile();
   if (!noexecute)
      {
      temp2 = temp1 + w;
      calcflags_add(temp1,w,temp2);
      if (!dest)  /* if W is destination */
         w = temp2;
      else
         setfile(temp2);
      regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | statushold;
      }
   }

void movf()             /* 001000 df ffff = MOVF */
   {
   temp1 = getfile();
   if (!noexecute)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (!dest)  /* if W is destination */
         w = temp1;
      else
         setfile(temp1);
      if (temp1)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      }
   }

void comf()             /* 001001 df ffff = COMF */
   {
   temp1 = ~getfile();
   if (!noexecute)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (!dest)  /* if W is destination */
         w = temp1;
      else
         setfile(temp1);
      if (temp1)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      }
   }

void incf()             /* 001010 df ffff = INCF */
   {
   temp1 = getfile() + 1;
   if (!noexecute)
      {
      statushold = regs[STATUS] & STATUS_FLAGBITS;  /* get flag values */
      if (!dest)  /* if W is destination */
         w = temp1;
      else
         setfile(temp1);
      if (temp1)
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_Z & statushold);
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_Z | statushold;
      }
   }

void decfsz()           /* 001011 df ffff = DECFSZ */
   {
   temp1 = getfile() - 1;
   if (!noexecute)
      {
      if (!dest)  /* if W is destination */
         w = temp1;
      else
         setfile(temp1);
      if (!temp1)
         {
         ip = (ip + 1) & MEMORY_MASK;
         timingcount++;  /* NOPs now in prefetch queue */
         }
      }
   }

void rrf()              /* 001100 df ffff = RRF */
   {
   temp1 = getfile();  /* get value to rotate */
   if (!noexecute)
      {
      temp2 = temp1 >> 1;  /* start of rotation */
      if ((statushold=regs[STATUS] & STATUS_FLAGBITS) & STATUS_C)  /* get flag values and check C */
         temp2 |= BIT7;  /* if C, put it in highbit of result */
      if (!dest)  /* if W is destination */
         w = temp2;
      else
         setfile(temp2);
      if (temp1 & 1)  /* set C out of lowbit */
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_C | statushold;
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_C & statushold);
      }
   }

void rlf()              /* 001101 df ffff = RLF */
   {
   temp1 = getfile();  /* get value to rotate */
   if (!noexecute)
      {
      temp2 = temp1 << 1;  /* start of rotation */
      if ((statushold=regs[STATUS] & STATUS_FLAGBITS) & STATUS_C)  /* get flag values and check C */
         temp2 |= BIT0;  /* if C, put it in lowbit of result */
      if (!dest)  /* if W is destination */
         w = temp2;
      else
         setfile(temp2);
      if (temp1 & BIT7)  /* set C out of highbit */
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | STATUS_C | statushold;
      else
         regs[STATUS] = (regs[STATUS] & STATUS_OTHERBITS) | (~STATUS_C & statushold);
      }
   }

void swapf()            /* 001110 df ffff = SWAPF */
   {
   temp1 = getfile();
   if (!noexecute)
      {
      temp2 = (temp1 >> 4) + (temp1 << 4);  /* swap nibbles */
      if (!dest)  /* if W is destination */
         w = temp2;
      else
         setfile(temp2);
      }
   }

void incfsz()           /* 001111 df ffff = INCFSZ */
   {
   temp1 = getfile() + 1;
   if (!noexecute)
      {
      if (!dest)  /* if W is destination */
         w = temp1;
      else
         setfile(temp1);
      if (!temp1)
         {
         ip = (ip + 1) & MEMORY_MASK;
         timingcount++;  /* NOPs now in prefetch queue */
         }
      }
   }

void bcf()              /* 0100bb bf ffff = BCF <00b> */
   {
   BYTE val, ch2;  /* ch2 to keep stack aligned */

   doing_portread = FALSE;
   val = getfile();
   if (doing_portread)
      val = regs[filenum_temp2];  /* if I/O port, don't read to change value! */
   setfile(val & ~bittable[(opcode & BITNUM_MASK) >> BITNUM_POSITION]);
   }

void bsf()              /* 0100bb bf ffff = BSF <00b> */
   {
   BYTE val, ch2;  /* ch2 to keep stack aligned */

   doing_portread = FALSE;
   val = getfile();
   if (doing_portread)
      val = regs[filenum_temp2];  /* if I/O port, don't read to change value! */
   setfile(val | bittable[(opcode & BITNUM_MASK) >> BITNUM_POSITION]);
   }

void btfsc()            /* 0110bb bf ffff = BTFSC <00b> */
   {
   if (!(getfile() & bittable[(opcode & BITNUM_MASK) >> BITNUM_POSITION]))
      {
      if (!noexecute)
         {
         ip = (ip + 1) & MEMORY_MASK;
         timingcount++;  /* NOPs now in prefetch queue */
         }
      }
   }

void btfss()            /* 0111bb bf ffff = BTFSS <00b> */
   {
   if ((getfile() & bittable[(opcode & BITNUM_MASK) >> BITNUM_POSITION]))
      {
      if (!noexecute)
         {
         ip = (ip + 1) & MEMORY_MASK;
         timingcount++;  /* NOPs now in prefetch queue */
         }
      }
   }

void retlw()            /* 1000kk kk kkkk = RETLW <kkkk kkkk> */
   {
   pop_ip();
   if (!noexecute)
      w = opcode;  /* get low byte of opcode */
   }

void call_12bit()       /* 1001kk kk kkkk = CALL <kkkk kkkk> */
   {
   push_ip();  /* save IP of next instruction */
   if (!noexecute)
      {
      timingcount++;  /* NOPs now in prefetch queue */
      ip = ((WORD)(regs[STATUS] & STATUS_PA0) << STATUS_PA0_SHIFT)
                   + (opcode & CALL_MASK_12BIT);
           /* note that bit 8 is implicitly cleared */
      }
   }

void go_to_12bit()      /* 101kkk kk kkkk = GOTO <k kkkk kkkk> */
   {
   timingcount++;  /* NOPs now in prefetch queue */
   ip = ((WORD)(regs[STATUS] & STATUS_PA0) << STATUS_PA0_SHIFT)
                + (opcode & GOTO_MASK_12BIT);
      /* all IP bits are accounted for */
   }

void movlw()            /* 1100kk kk kkkk = MOVLW <kkkk kkkk> */
   {
   w = opcode;  /* since W is a BYTE, we just get the low 8 bits */
   }

void iorlw()            /* 1101kk kk kkkk = IORLW <kkkk kkkk> */
   {
   w |= opcode;  /* since W is a BYTE, we just use the low 8 bits of opcode */
   if (w)
      regs[STATUS] &= ~STATUS_Z;
   else
      regs[STATUS] |= STATUS_Z;
   }

void andlw()            /* 1110kk kk kkkk = ANDLW <kkkk kkkk> */
   {
   w &= opcode;  /* since W is a BYTE, we just use the low 8 bits of opcode */
   if (w)
      regs[STATUS] &= ~STATUS_Z;
   else
      regs[STATUS] |= STATUS_Z;
   }

void xorlw()            /* 1111kk kk kkkk = XORLW <kkkk kkkk> */
   {
   w ^= opcode;  /* since W is a BYTE, we just use the low 8 bits of opcode */
   if (w)
      regs[STATUS] &= ~STATUS_Z;
   else
      regs[STATUS] |= STATUS_Z;
   }

void nop()              /* 000000 00 0000 or 000000 0000 0000 or 111011 xxxx xxxx */
   {
   }

#ifdef ALIGN_PICOPS_1
   static BYTE alignpicops_1 = 0;
#endif  /* ALIGN_PICOPS_1 */
#ifdef ALIGN_PICOPS_2
   static WORD alignpicops_2 = 0;
#endif  /* ALIGN_PICOPS_2 */

void (*picops[1 << PIC_DECODE_BITS])() =
   {
   controls_12bit,   /* 000000 xx xxxx = NOP/OPTION/SLEEP/CLRWDT/TRIS/MOVWF */
   clr_12bit,        /* 000001 xx xxxx = CLRW / CLRF */
   subwf,            /* 000010 df ffff = SUBWF */
   decf,             /* 000011 df ffff = DECF */
   iorwf,            /* 000100 df ffff = IORWF */
   andwf,            /* 000101 df ffff = ANDWF */
   xorwf,            /* 000110 df ffff = XORWF */
   addwf,            /* 000111 df ffff = ADDWF */
   movf,             /* 001000 df ffff = MOVF */
   comf,             /* 001001 df ffff = COMF */
   incf,             /* 001010 df ffff = INCF */
   decfsz,           /* 001011 df ffff = DECFSZ */
   rrf,              /* 001100 df ffff = RRF */
   rlf,              /* 001101 df ffff = RLF */
   swapf,            /* 001110 df ffff = SWAPF */
   incfsz,           /* 001111 df ffff = INCFSZ */
   bcf,              /* 010000 bf ffff (0100bb bf ffff) = BCF <00b> */
   bcf,              /* 010001 bf ffff (0100bb bf ffff) = BCF <01b> */
   bcf,              /* 010010 bf ffff (0100bb bf ffff) = BCF <10b> */
   bcf,              /* 010011 bf ffff (0100bb bf ffff) = BCF <11b> */
   bsf,              /* 010100 bf ffff (0101bb bf ffff) = BSF <00b> */
   bsf,              /* 010101 bf ffff (0101bb bf ffff) = BSF <01b> */
   bsf,              /* 010110 bf ffff (0101bb bf ffff) = BSF <10b> */
   bsf,              /* 010111 bf ffff (0101bb bf ffff) = BSF <11b> */
   btfsc,            /* 011000 bf ffff (0110bb bf ffff) = BTFSC <00b> */
   btfsc,            /* 011001 bf ffff (0110bb bf ffff) = BTFSC <01b> */
   btfsc,            /* 011010 bf ffff (0110bb bf ffff) = BTFSC <10b> */
   btfsc,            /* 011011 bf ffff (0110bb bf ffff) = BTFSC <11b> */
   btfss,            /* 011100 bf ffff (0111bb bf ffff) = BTFSS <00b> */
   btfss,            /* 011101 bf ffff (0111bb bf ffff) = BTFSS <01b> */
   btfss,            /* 011110 bf ffff (0111bb bf ffff) = BTFSS <10b> */
   btfss,            /* 011111 bf ffff (0111bb bf ffff) = BTFSS <11b> */
   retlw,            /* 100000 kk kkkk (1000kk kk kkkk) = RETLW <00kk kkkk> */
   retlw,            /* 100001 kk kkkk (1000kk kk kkkk) = RETLW <01kk kkkk> */
   retlw,            /* 100010 kk kkkk (1000kk kk kkkk) = RETLW <10kk kkkk> */
   retlw,            /* 100011 kk kkkk (1000kk kk kkkk) = RETLW <11kk kkkk> */
   call_12bit,       /* 100100 kk kkkk (1001kk kk kkkk) = CALL <00kk kkkk> */
   call_12bit,       /* 100101 kk kkkk (1001kk kk kkkk) = CALL <01kk kkkk> */
   call_12bit,       /* 100110 kk kkkk (1001kk kk kkkk) = CALL <10kk kkkk> */
   call_12bit        /* 100111 kk kkkk (1001kk kk kkkk) = CALL <11kk kkkk> */
   go_to_12bit,      /* 101000 kk kkkk (101kkk kk kkkk) = GOTO <0 00kk kkkk> */
   go_to_12bit,      /* 101001 kk kkkk (101kkk kk kkkk) = GOTO <0 01kk kkkk> */
   go_to_12bit,      /* 101010 kk kkkk (101kkk kk kkkk) = GOTO <0 10kk kkkk> */
   go_to_12bit,      /* 101011 kk kkkk (101kkk kk kkkk) = GOTO <0 11kk kkkk> */
   go_to_12bit,      /* 101100 kk kkkk (101kkk kk kkkk) = GOTO <1 00kk kkkk> */
   go_to_12bit,      /* 101101 kk kkkk (101kkk kk kkkk) = GOTO <1 01kk kkkk> */
   go_to_12bit,      /* 101110 kk kkkk (101kkk kk kkkk) = GOTO <1 10kk kkkk> */
   go_to_12bit,      /* 101111 kk kkkk (101kkk kk kkkk) = GOTO <1 11kk kkkk> */
   movlw,            /* 110000 kk kkkk (1100kk kk kkkk) = MOVLW <00kk kkkk> */
   movlw,            /* 110001 kk kkkk (1100kk kk kkkk) = MOVLW <01kk kkkk> */
   movlw,            /* 110010 kk kkkk (1100kk kk kkkk) = MOVLW <10kk kkkk> */
   movlw,            /* 110011 kk kkkk (1100kk kk kkkk) = MOVLW <11kk kkkk> */
   iorlw,            /* 110100 kk kkkk (1101kk kk kkkk) = IORLW <00kk kkkk> */
   iorlw,            /* 110101 kk kkkk (1101kk kk kkkk) = IORLW <01kk kkkk> */
   iorlw,            /* 110110 kk kkkk (1101kk kk kkkk) = IORLW <10kk kkkk> */
   iorlw,            /* 110111 kk kkkk (1101kk kk kkkk) = IORLW <11kk kkkk> */
   andlw,            /* 111000 kk kkkk (1110kk kk kkkk) = ANDLW <00kk kkkk> */
   andlw,            /* 111001 kk kkkk (1110kk kk kkkk) = ANDLW <01kk kkkk> */
   andlw,            /* 111010 kk kkkk (1110kk kk kkkk) = ANDLW <10kk kkkk> */
   andlw,            /* 111011 kk kkkk (1110kk kk kkkk) = ANDLW <11kk kkkk> */
   xorlw,            /* 111100 kk kkkk (1111kk kk kkkk) = XORLW <00kk kkkk> */
   xorlw,            /* 111101 kk kkkk (1111kk kk kkkk) = XORLW <01kk kkkk> */
   xorlw,            /* 111110 kk kkkk (1111kk kk kkkk) = XORLW <10kk kkkk> */
   xorlw             /* 111111 kk kkkk (1111kk kk kkkk) = XORLW <11kk kkkk> */
   };

watchdog_expired()
   {
   if (chkwatchdog)
      breakpoint = BRK_WATCHDOG;
   if (sleepmode)
      {
      sleepmode = FALSE;
      regs[STATUS] &= ~STATUS_PD;
      }
   ip = RESET_IP;
   tmr0_prescale_counter = 0;
   regs[STATUS] &= ~STATUS_TO;
   regs[STATUS] &= ~STATUS_GPWUF;
   regs[FSR] |= RESET_FSR;
   regs[OPTION] = OPTION_RESET;
   tmr0_prescale = bittable[regs[OPTION] & OPTION_PRESCALE_BITS];
   if (!(regs[OPTION] & PSA))  /* if prescale assigned to TMR0 */
      tmr0_prescale <<= 1;  /* prescale is 2 .. 256 */
   regs[TRISA] = RESET_TRIS;
   last_t0cki = 0;  /* reset edge detection */
   last_wakepins = input_ports[0];
   watchdog = watchdog_reset_count;
   do_mclr_reset = FALSE;
   }

pinchange_wakeup()
   {
   sleepmode = FALSE;
   ip = RESET_IP;
   watchdog = watchdog_reset_count;
   do_mclr_reset = FALSE;
   tmr0_prescale_counter = 0;
   regs[STATUS] &= ~STATUS_PD;
   regs[STATUS] |= STATUS_TO;
   regs[STATUS] |= STATUS_GPWUF;
   regs[FSR] |= RESET_FSR;
   regs[OPTION] = OPTION_RESET;
   tmr0_prescale = bittable[regs[OPTION] & OPTION_PRESCALE_BITS];
   if (!(regs[OPTION] & PSA))  /* if prescale assigned to TMR0 */
      tmr0_prescale <<= 1;  /* prescale is 2 .. 256 */
   regs[TRISA] = RESET_TRIS;
   last_t0cki = 0;  /* reset edge detection */
   last_wakepins = input_ports[0];
   }

mclr_reset()
   {
   if (sleepmode)
      {
      sleepmode = FALSE;
      regs[STATUS] &= ~STATUS_PD;
      regs[STATUS] |= STATUS_TO;
      }
   watchdog = watchdog_reset_count;
   do_mclr_reset = FALSE;
   ip = RESET_IP;
   tmr0_prescale_counter = 0;
   regs[STATUS] &= ~STATUS_GPWUF;
   regs[FSR] |= RESET_FSR;
   regs[OPTION] = OPTION_RESET;
   tmr0_prescale = bittable[regs[OPTION] & OPTION_PRESCALE_BITS];
   if (!(regs[OPTION] & PSA))  /* if prescale assigned to TMR0 */
      tmr0_prescale <<= 1;  /* prescale is 2 .. 256 */
   regs[TRISA] = RESET_TRIS;
   last_t0cki = 0;  /* reset edge detection */
   last_wakepins = input_ports[0];
   }

reset(clear_screen)
   WORD clear_screen;
   {
   WORD i;
   WORD save_show_ports;

   save_show_ports = show_ports;
   for (i = 0; i < WHERE_SIZE+1; i++)
      wherequeue[i] = 0xffff;  /* invalid address */
   sleepmode = FALSE;
   stack_ptr = 0;
   stack_depth = 0;
   max_stack_depth = 0;
   ip = RESET_IP;
   unasm_ip = RESET_IP;
   regs[PCL] = RESET_IP;
   asm_ip = 0;
   tmr0_inhibit = 0;  /* OK to update TIMER0 */
   watchdog = watchdog_reset_count;
   do_mclr_reset = FALSE;
   regs[OPTION] = OPTION_RESET;
   tmr0_prescale = bittable[regs[OPTION] & OPTION_PRESCALE_BITS];
   if (!(regs[OPTION] & PSA))  /* if prescale assigned to TMR0 */
      tmr0_prescale <<= 1;  /* prescale is 2 .. 256 */
   tmr0_prescale_counter = 0;
   regs[TRISA] = RESET_TRIS;
   last_t0cki = 0;  /* reset edge detection */
   regs[FSR] = RESET_FSR;
   regs[OSCCAL] = RESET_OSCCAL;
   regs[STATUS] = RESET_STATUS;
   temp2 = show_ports;
   show_ports = FALSE;
   /* setreg(GPIO,initial_ports[0]); */  /* 12-bit core only has the one I/O reg */
   input_ports[0] = initial_ports[0];  /* set initial port values */
   last_wakepins = input_ports[0];
   show_ports = temp2;
   if (clear_screen)
      {
      for (i = 0; i < SCREEN_ROWS * SCREEN_COLS * 2; i += 2)
         {
         uart_screen[i] = 0x20;  /* space */
         uart_screen[i+1] = 0x07;  /* normal attribute */
         }
      screen_rowofs = 0;
      screen_colofs = 0;
      hex_kbd_hold = 0;
      }
   io_processing();
   show_ports = save_show_ports;
   }

setup_stimulus()
   {
   if (stopwatchcount[1] == 0)  /* stimulus only has a 32-bit range */
      {
      for (stimulus_index = 0, pstim = stimulus; stimulus_index < num_stimulus; stimulus_index++, pstim++)
         {
         if (pstim->cyclecount == stopwatchcount[0])
            {
            for (wtemp3 = 0; wtemp3 < NUM_BYTE_PORTS; wtemp3++)
               {
               for (temp2 = 1, wtemp4 = 0; wtemp4 < 8; temp2 <<= 1, wtemp4++)
                  {
                  if (stim_pinmasks[wtemp3] & temp2)
                     {
                     analog_ports[wtemp3][wtemp4] = pstim->pinvals[wtemp3][wtemp4];
                     (*portbitfns[wtemp3 * 8 + wtemp4])(0xffff);
                     }
                  }
               } /* wtemp3 */
            }  /* if (pstim->cyclecount == stopwatchcount[0]) */
         if (pstim->cyclecount > stopwatchcount[0])
            {
            stimulus_delay[1] = 0;  /* high word is always 0 */
            stimulus_delay[0] = pstim->cyclecount - stopwatchcount[0];
#asm
   mov  ax,word instructioncount_   ;do a 64-bit add
   add  word stimulus_delay_,ax
   mov  ax,word instructioncount_[2]
   adc  word stimulus_delay_[2],ax
   mov  ax,word instructioncount_[4]
   adc  word stimulus_delay_[4],ax
   mov  ax,word instructioncount_[6]
   adc  word stimulus_delay_[6],ax
#endasm
            break;  /* that's all for this loop */
            }
         }
      }
   if ((stopwatchcount[1])  /* stimulus only has a 32-bit range */
              || (stimulus_index == num_stimulus))  /* or beyond last stimulus */
      {
      stimulus_delay[0] =
      stimulus_delay[1] = 0xffffffff;  /* basically forever */
      }
   }

#ifdef NEVERDEF
** godoit()  /* execute */
**    {
** #ifdef USE_ADDRLIST
**    if (have_addrlist)
**       addrlist = TRUE;
** #endif  /* USE_ADDRLIST */
**    breakpoint = BRK_NONE;
**    noexecute = FALSE;
**    instructioncount[0] = 0;  /* do a 64-bit 0 */
**    instructioncount[1] = 0;
**    stopwatch_reset_time[0] = 0;
**    stopwatch_reset_time[1] = 0;
** #ifdef HAS_UART
**    tx_port_available = TRUE;
** #endif  /* HAS_UART */
**    setup_stimulus();
**    screen_swap();
** /*   if (show_ports) */
**       io_processing();
**    get_starttime();
**    stopwatch_startticks = startticks;
**    if (num_watch_regs)
**       {
**       update_watch_display();
**       watch_regs_delay = WATCH_DELAY;
**       }
**    if (oscope_lines)
**       show_oscope();
**    if (have_tickcount | num_watch_regs)
**       take_int8();
**    take_int9();
**    while (!breakpoint)
**       {
**       wherequeue[whereptr] = ip;
**       opcode = memory[ip] & INSTRUCTION_BITMASK;
**       for (timingtemp = 0; timingtemp < num_mem_breakpoints; timingtemp++)
**          if ((mem_breaks[timingtemp].low <= ip)
**                              && (mem_breaks[timingtemp].high >= ip))
**             {
**             breakpoint = BRK_MEMORY;
**             noexecute = TRUE;
**             break;  /* no need to loop more */
**             }
**       if ((!sleepmode) && (!noexecute))
**          {
**          ip = (ip + 1) & MEMORY_MASK;
**          regs[PCL] = ip;  /* update PCL */
**          filenum = opcode & REGINDEX_MASK;  /* isolate register file */
**          dest = opcode & DEST_MASK;  /* isolate F/!W bit */
**          timingcount = 1;   /* default: instruction is 1 cycle */
**          (*picops[opcode >> OPTYPES_SHIFT])();  /* get 6 bits of instruction decode */
**          }
**       if (sleepmode)
**          {
**          if ((!(regs[OPTION] & GPWU)) &&
**                 (((last_wakepins ^ input_ports[0]) & regs[TRISA]) & wakemask))
**             pinchange_wakeup();
**          }
**       last_wakepins = input_ports[0];
**       if (!noexecute)
**          {
**          whereptr = (whereptr + 1) & WHERE_SIZE;
**          for (timingtemp = 0; timingtemp < timingcount; timingtemp++)
**             {
** #asm
**    add  word instructioncount_,1           ;do a 64-bit INC
**    adc  word instructioncount_[2],0
**    adc  word instructioncount_[4],0
**    adc  word instructioncount_[6],0
** #endasm
**             if (regs[OPTION] & PSA)  /* if prescale assigned to WDT */
**                {
**                if (++tmr0_prescale_counter >= tmr0_prescale)
**                   {
**                   if (watchdog_enabled)
**                      {
**                      if (!(++watchdog))
**                         watchdog_expired();
**                      }  /* watchdog enabled */
**                   tmr0_prescale_counter = 0;
**                   }
**                if ((!(regs[OPTION] & T0CS))
**                            && (!tmr0_inhibit)
**                            && (!sleepmode))
**                   regs[TMR0]++;
**                }
**             else  /* prescalar assigned to TMR0 */
**                {
**                if ((!sleepmode)
**                          && (!(regs[OPTION] & T0CS))
**                          && (!tmr0_inhibit)
**                          && (++tmr0_prescale_counter >= tmr0_prescale))
**                   {
**                   regs[TMR0]++;
**                   tmr0_prescale_counter = 0;
**                   }
**                if (watchdog_enabled)
**                   if (!(++watchdog))
**                      watchdog_expired();
**                }
**             if ((tmr0_inhibit) && (!sleepmode))
**                tmr0_inhibit--;
** /*
**  *            if (instructioncount == stimulus_delay)
**  *              ...
**  */
** #asm
**    mov  word wtemp3_,1               ;default to FALSE (sort of...)
**    mov  ax,word instructioncount_[6] ;do a 64-bit compare
**    cmp  ax,word stimulus_delay_[6]
**    jne  gdi_nostim
**    mov  ax,word instructioncount_[4]
**    cmp  ax,word stimulus_delay_[4]
**    jne  gdi_nostim
**    mov  ax,word instructioncount_[2]
**    cmp  ax,word stimulus_delay_[2]
**    jne  gdi_nostim
**    mov  ax,word instructioncount_
**    cmp  ax,word stimulus_delay_
**    jne  gdi_nostim
**    mov  word wtemp3_,0         ;set flag, time for stimulus
** gdi_nostim:
** #endasm
**             if (!wtemp3)
**                {
**                for ( ; wtemp3 < NUM_BYTE_PORTS; wtemp3++)
**                   {
**                   for (temp2 = 1, wtemp4 = 0; wtemp4 < 8; temp2 <<= 1, wtemp4++)
**                      {
**                      if (stim_pinmasks[wtemp3] & temp2)
**                         {
**                         analog_ports[wtemp3][wtemp4] = pstim->pinvals[wtemp3][wtemp4];
**                         (*portbitfns[wtemp3 * 8 + wtemp4])(0xffff);
**                         io_processing();
**                         }
**                      }
**                   } /* wtemp3 */
**                if (stimulus_index < num_stimulus)
**                   {
**                   stimulus_delay[0] -= pstim->cyclecount;
**                   pstim++;
** /*                  stimulus_index++; */
**                   if (++stimulus_index == num_stimulus)
**                      {
**                      if (periodic_stim)
**                         {
**                         stopwatchcount[1] =
**                         stopwatchcount[0] = 0;
**                         stopwatchticks = 0;
**                         stopwatch_reset_time[0] = instructioncount[0];
**                         stopwatch_reset_time[1] = instructioncount[1];
** #asm
**    mov  cx,ds       ;save ds
**    xor  ax,ax       ;get a 0
**    mov  ds,ax
**    lds  ax,word [46ch]  ;get current ticks
**    mov  dx,ds       ;save ticks highword
**    mov  ds,cx       ;reset our ds
**    mov  word stopwatch_startticks_,ax
**    mov  word stopwatch_startticks_[2],dx
** #endasm
** #ifdef HAS_ADC
**                         adc_table_index = 0;
** #endif  /* HAS_ADC */
**                         setup_stimulus();
** /*                        stimulus_delay[0] += pstim->cyclecount; */
**                         }
**                      else
**                         {
**                         stimulus_delay[1] =
**                         stimulus_delay[0] = 0xffffffff;
**                         }
**                      }
**                   else
**                      {
**                      stimulus_delay[0] += pstim->cyclecount;
**                      }
**                   }
**                }  /* if (!wtemp3) */ /* if (instructioncount == stimulus_delay) */
**             if (su_rxtiming)  /* if xmit to PIC */
**                {
**                if (!(--su_rxtiming))  /* if time for next bit */
**                   {
**                   input_ports[su_rxport] = (input_ports[su_rxport] & ~su_rxbitmask) | ((su_rxdata & 1) << su_rxpin);
**                   analog_ports[su_rxport][su_rxpin] =  (input_ports[su_rxport] & su_rxbitmask) ? 0xffff : 0;
**                   su_rxdata >>= 1;
** /*                  if (show_ports) */
**                      io_processing();
**                   if (++su_rxcount != su_rxtotalbits)
**                      su_rxtiming = su_rxbittiming;
**                   else
**                      setup_softuart_rx();  /* do next char in queue, if any */
**                   }
**                }
**             if (su_txtiming)  /* if rcv from PIC */
**                {
**                if (!(--su_txtiming))  /* if time for next bit */
**                   {
**                   if (!(regs[TRISA] & su_txbitmask))  /* if output pin */
**                      {
**                      su_txdata |= ((regs[GPIO] ^ su_txinvert) & su_txbitmask) >> su_txpin;
** #asm
**    ror  word su_txdata_,1   ;keep this fast!
** #endasm
**                      }
**                   if (++su_txcount != su_txtotalbits)
**                      su_txtiming = su_txbittiming;
**                   else
**                      {
**                      if ((su_txdata & su_txframemask) == su_txstopmask)  /* if right start/stop bits */
**                         uart_screen_char((su_txdata >> su_txdatashift) & su_txdatamask);
**                      }
**                   }
**                }
**             if (oscope_count)
**                {
**                if (!(--oscope_count))
**                   {
**                   update_oscope();
**                   oscope_count = oscope_delay;
**                   }
**                }
**             if (do_mclr_reset)
**                mclr_reset();
**             }  /* for (timingtemp...) */
**          if (io_processing_waiting)
**             {
**             io_processing_waiting = FALSE;
**             io_processing();
**             }
**          }  /* if (!noexecute) */
**       else
**          {
**          ip = wherequeue[whereptr];  /* reset IP */
**          regs[PCL] = ip;  /* update PCL */
**          }
**       }
**    if (have_tickcount | num_watch_regs)
**       reset_int8();
**    reset_int9();
**    get_endtime();
**    screen_swap();
** #asm
**    mov  ax,word instructioncount_   ;do a 64-bit add
**    add  word total_ic_,ax
**    mov  ax,word instructioncount_[2]
**    adc  word total_ic_[2],ax
**    mov  ax,word instructioncount_[4]
**    adc  word total_ic_[4],ax
**    mov  ax,word instructioncount_[6]
**    adc  word total_ic_[6],ax
**    mov  ax,word instructioncount_   ;do a 64-bit add
**    add  word stopwatchcount_,ax
**    mov  ax,word instructioncount_[2]
**    adc  word stopwatchcount_[2],ax
**    mov  ax,word instructioncount_[4]
**    adc  word stopwatchcount_[4],ax
**    mov  ax,word instructioncount_[6]
**    adc  word stopwatchcount_[6],ax
**    mov  ax,word stopwatch_reset_time_   ;do a 64-bit sub
**    sub  word stopwatchcount_,ax
**    mov  ax,word stopwatch_reset_time_[2]
**    sbb  word stopwatchcount_[2],ax
**    mov  ax,word stopwatch_reset_time_[4]
**    sbb  word stopwatchcount_[4],ax
**    mov  ax,word stopwatch_reset_time_[6]
**    sbb  word stopwatchcount_[6],ax
** #endasm
** /*   breakpoint = FALSE; */  /* let user shell know which breakpoint we hit */
**    noexecute = FALSE;
** #ifdef USE_ADDRLIST
**    addrlist = FALSE;
** #endif  /* USE_ADDRLIST */
**    }
#endif  /* NEVERDEF */

execute()  /* execute */
   {
#ifdef EX_1B
#asm
   nop        ;code alignment
#endasm
#endif  /* EX_1B */

#ifdef EX_2B
#asm
   nop        ;code alignment
   nop        ;code alignment
#endasm
#endif  /* EX_2B */

#ifdef EX_4B
#asm
   nop        ;code alignment
   nop        ;code alignment
   nop        ;code alignment
   nop        ;code alignment
#endasm
#endif  /* EX_4B */

#ifdef EX_8B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
#endasm
#endif  /* EX_8B */

#ifdef EX_16B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
   nop        ;code alignment  9
   nop        ;code alignment  10
   nop        ;code alignment  11
   nop        ;code alignment  12
   nop        ;code alignment  13
   nop        ;code alignment  14
   nop        ;code alignment  15
   nop        ;code alignment  16
#endasm
#endif  /* EX_16B */

#ifdef EX_32B
#asm
   nop        ;code alignment  1
   nop        ;code alignment  2
   nop        ;code alignment  3
   nop        ;code alignment  4
   nop        ;code alignment  5
   nop        ;code alignment  6
   nop        ;code alignment  7
   nop        ;code alignment  8
   nop        ;code alignment  9
   nop        ;code alignment  10
   nop        ;code alignment  11
   nop        ;code alignment  12
   nop        ;code alignment  13
   nop        ;code alignment  14
   nop        ;code alignment  15
   nop        ;code alignment  16
   nop        ;code alignment  17
   nop        ;code alignment  18
   nop        ;code alignment  19
   nop        ;code alignment  20
   nop        ;code alignment  21
   nop        ;code alignment  22
   nop        ;code alignment  23
   nop        ;code alignment  24
   nop        ;code alignment  25
   nop        ;code alignment  26
   nop        ;code alignment  27
   nop        ;code alignment  28
   nop        ;code alignment  29
   nop        ;code alignment  30
   nop        ;code alignment  31
   nop        ;code alignment  32
#endasm
#endif  /* EX_32B */

#ifdef USE_ADDRLIST
   if (have_addrlist)
      addrlist = TRUE;
#endif  /* USE_ADDRLIST */
   breakpoint = BRK_NONE;
   noexecute = FALSE;
   instructioncount[0] = 0;  /* do a 64-bit 0 */
   instructioncount[1] = 0;
   stopwatch_reset_time[0] = 0;
   stopwatch_reset_time[1] = 0;
#ifdef HAS_UART
   tx_port_available = TRUE;
#endif  /* HAS_UART */
   setup_stimulus();
   screen_swap();
/*   if (show_ports) */
      io_processing();
   get_starttime();
   stopwatch_startticks = startticks;
   if (num_watch_regs)
      {
      update_watch_display();
      watch_regs_delay = WATCH_DELAY;
      }
   if (oscope_lines)
      show_oscope();
   if (have_tickcount | num_watch_regs)
      take_int8();
   take_int9();
   while (!breakpoint)
      {
      wherequeue[whereptr] = ip;
      opcode = memory[ip] & INSTRUCTION_BITMASK;
      for (timingtemp = 0; timingtemp < num_mem_breakpoints; timingtemp++)
         if ((mem_breaks[timingtemp].low <= ip)
                             && (mem_breaks[timingtemp].high >= ip))
            {
            breakpoint = BRK_MEMORY;
            noexecute = TRUE;
            break;  /* no need to loop more */
            }
      if ((!sleepmode) && (!noexecute))
         {
         ip = (ip + 1) & MEMORY_MASK;
         regs[PCL] = ip;  /* update PCL */
         filenum = opcode & REGINDEX_MASK;  /* isolate register file */
         dest = opcode & DEST_MASK;  /* isolate F/!W bit */
         timingcount = 1;   /* default: instruction is 1 cycle */
         (*picops[opcode >> OPTYPES_SHIFT])();  /* get 6 bits of instruction decode */
         }
      if (sleepmode)
         {
         if ((!(regs[OPTION] & GPWU)) &&
                (((last_wakepins ^ input_ports[0]) & regs[TRISA]) & wakemask))
            pinchange_wakeup();
         }
      last_wakepins = input_ports[0];
      if (!noexecute)
         {
         whereptr = (whereptr + 1) & WHERE_SIZE;
         for (timingtemp = 0; timingtemp < timingcount; timingtemp++)
            {
#asm
   add  word instructioncount_,1           ;do a 64-bit INC
   adc  word instructioncount_[2],0
   adc  word instructioncount_[4],0
   adc  word instructioncount_[6],0
#endasm
            for (throttlecount = throttle; throttlecount; throttlecount--)
               ;  /* waste a little time */
            if (regs[OPTION] & PSA)  /* if prescale assigned to WDT */
               {
               if (++tmr0_prescale_counter >= tmr0_prescale)
                  {
                  if (watchdog_enabled)
                     {
                     if (!(++watchdog))
                        watchdog_expired();
                     }  /* watchdog enabled */
                  tmr0_prescale_counter = 0;
                  }
               if ((!(regs[OPTION] & T0CS))
                           && (!tmr0_inhibit)
                           && (!sleepmode))
                  regs[TMR0]++;
               }
            else  /* prescalar assigned to TMR0 */
               {
               if ((!sleepmode)
                         && (!(regs[OPTION] & T0CS))
                         && (!tmr0_inhibit)
                         && (++tmr0_prescale_counter >= tmr0_prescale))
                  {
                  regs[TMR0]++;
                  tmr0_prescale_counter = 0;
                  }
               if (watchdog_enabled)
                  if (!(++watchdog))
                     watchdog_expired();
               }
            if ((tmr0_inhibit) && (!sleepmode))
               tmr0_inhibit--;
/*
 *            if (instructioncount == breakcount)
 *              breakpoint = BRK_COUNT;
 */
#asm
   mov  ax,word instructioncount_   ;do a 64-bit compare
   cmp  ax,word breakcount_
   jne  no_breakpoint_count
   mov  ax,word instructioncount_[2]
   cmp  ax,word breakcount_[2]
   jne  no_breakpoint_count
   mov  ax,word instructioncount_[4]
   cmp  ax,word breakcount_[4]
   jne  no_breakpoint_count
   mov  ax,word instructioncount_[6]
   cmp  ax,word breakcount_[6]
   jne  no_breakpoint_count
   mov  word breakpoint_,4     ;set breakpoint BRK_COUNT
        ;NOTE: don't have to worry about noexecute here
no_breakpoint_count:
#endasm
/*
 *            if (instructioncount == stimulus_delay)
 *              ...
 */
#asm
   mov  word wtemp3_,1               ;default to FALSE (sort of...)
   mov  ax,word instructioncount_[6] ;do a 64-bit compare
   cmp  ax,word stimulus_delay_[6]
   jne  exec_nostim
   mov  ax,word instructioncount_[4]
   cmp  ax,word stimulus_delay_[4]
   jne  exec_nostim
   mov  ax,word instructioncount_[2]
   cmp  ax,word stimulus_delay_[2]
   jne  exec_nostim
   mov  ax,word instructioncount_
   cmp  ax,word stimulus_delay_
   jne  exec_nostim
   mov  word wtemp3_,0         ;set flag, time for stimulus
exec_nostim:
#endasm
            if (!wtemp3)
               {
               for ( ; wtemp3 < NUM_BYTE_PORTS; wtemp3++)
                  {
                  for (temp2 = 1, wtemp4 = 0; wtemp4 < 8; temp2 <<= 1, wtemp4++)
                     {
                     if (stim_pinmasks[wtemp3] & temp2)
                        {
                        analog_ports[wtemp3][wtemp4] = pstim->pinvals[wtemp3][wtemp4];
                        (*portbitfns[wtemp3 * 8 + wtemp4])(0xffff);
                        io_processing();
                        }
                     }
                  } /* wtemp3 */
               if (stimulus_index < num_stimulus)
                  {
                  stimulus_delay[0] -= pstim->cyclecount;
                  pstim++;
/*                  stimulus_index++; */
                  if (++stimulus_index == num_stimulus)
                     {
                     if (periodic_stim)
                        {
                        stopwatchcount[1] =
                        stopwatchcount[0] = 0;
                        stopwatchticks = 0;
                        stopwatch_reset_time[0] = instructioncount[0];
                        stopwatch_reset_time[1] = instructioncount[1];
#asm
   mov  cx,ds       ;save ds
   xor  ax,ax       ;get a 0
   mov  ds,ax
   lds  ax,word [46ch]  ;get current ticks
   mov  dx,ds       ;save ticks highword
   mov  ds,cx       ;reset our ds
   mov  word stopwatch_startticks_,ax
   mov  word stopwatch_startticks_[2],dx
#endasm
#ifdef HAS_ADC
                        adc_table_index = 0;
#endif  /* HAS_ADC */
                        setup_stimulus();
/*                        stimulus_delay[0] += pstim->cyclecount; */
                        }
                     else
                        {
                        stimulus_delay[1] =
                        stimulus_delay[0] = 0xffffffff;
                        }
                     }
                  else
                     {
                     stimulus_delay[0] += pstim->cyclecount;
                     }
                  }
               }  /* if (!wtemp3) */ /* if (instructioncount == stimulus_delay) */
            if (su_rxtiming)  /* if xmit to PIC */
               {
               if (!(--su_rxtiming))  /* if time for next bit */
                  {
                  input_ports[su_rxport] = (input_ports[su_rxport] & ~su_rxbitmask) | ((su_rxdata & 1) << su_rxpin);
                  analog_ports[su_rxport][su_rxpin] =  (input_ports[su_rxport] & su_rxbitmask) ? 0xffff : 0;
                  su_rxdata >>= 1;
/*                  if (show_ports) */
                     io_processing();
                  if (++su_rxcount != su_rxtotalbits)
                     su_rxtiming = su_rxbittiming;
                  else
                     setup_softuart_rx();  /* do next char in queue, if any */
                  }
               }
            if (su_txtiming)  /* if rcv from PIC */
               {
               if (!(--su_txtiming))  /* if time for next bit */
                  {
                  if (!(regs[TRISA] & su_txbitmask))  /* if output pin */
                     {
                     su_txdata |= ((regs[GPIO] ^ su_txinvert) & su_txbitmask) >> su_txpin;
#asm
   ror  word su_txdata_,1   ;keep this fast!
#endasm
                     }
                  if (++su_txcount != su_txtotalbits)
                     su_txtiming = su_txbittiming;
                  else
                     {
                     if ((su_txdata & su_txframemask) == su_txstopmask)  /* if right start/stop bits */
                        uart_screen_char((su_txdata >> su_txdatashift) & su_txdatamask);
                     }
                  }
               }
            if (oscope_count)
               {
               if (!(--oscope_count))
                  {
                  update_oscope();
                  oscope_count = oscope_delay;
                  }
               }
            if (do_mclr_reset)
               mclr_reset();
            }  /* for (timingtemp...) */
         if (io_processing_waiting)
            {
            io_processing_waiting = FALSE;
            io_processing();
            }
         }  /* if (!noexecute) */
      else
         {
         ip = wherequeue[whereptr];  /* reset IP */
         regs[PCL] = ip;  /* update PCL */
         }
      }  /* while (!breakpoint) */
   if (have_tickcount | num_watch_regs)
      reset_int8();
   reset_int9();
   get_endtime();
   screen_swap();
#asm
   mov  ax,word instructioncount_   ;do a 64-bit add
   add  word total_ic_,ax
   mov  ax,word instructioncount_[2]
   adc  word total_ic_[2],ax
   mov  ax,word instructioncount_[4]
   adc  word total_ic_[4],ax
   mov  ax,word instructioncount_[6]
   adc  word total_ic_[6],ax
   mov  ax,word instructioncount_   ;do a 64-bit add
   add  word stopwatchcount_,ax
   mov  ax,word instructioncount_[2]
   adc  word stopwatchcount_[2],ax
   mov  ax,word instructioncount_[4]
   adc  word stopwatchcount_[4],ax
   mov  ax,word instructioncount_[6]
   adc  word stopwatchcount_[6],ax
   mov  ax,word stopwatch_reset_time_   ;do a 64-bit sub
   sub  word stopwatchcount_,ax
   mov  ax,word stopwatch_reset_time_[2]
   sbb  word stopwatchcount_[2],ax
   mov  ax,word stopwatch_reset_time_[4]
   sbb  word stopwatchcount_[4],ax
   mov  ax,word stopwatch_reset_time_[6]
   sbb  word stopwatchcount_[6],ax
#endasm
/*   breakpoint = FALSE; */  /* let user shell know which breakpoint we hit */
   noexecute = FALSE;
#ifdef USE_ADDRLIST
   addrlist = FALSE;
#endif  /* USE_ADDRLIST */
   }
