#ifdef NEVERDEF
/****************************************************************************
 ****************************************************************************
 *                                                                          *
 *   WARNING!                                                               *
 *                                                                          *
 *   I've discovered a bug in the code optimizer.  A definition like:       *
 *      #define TESTBITS (BIT1|BIT2)                                        *
 *   can produce incorrect code output from the optimizer when TESTBITS     *
 *   is used.                                                               *
 *                                                                          *
 *   Instead, use a definition like:                                        *
 *      #define TESTBITS 0x05  /* (BIT1|BIT2) */                            *
 *   Yes, that's not as "ideal", but it will save a WORLD of problems!      *
 *                                                                          *
 ****************************************************************************
 ****************************************************************************/
#endif

/*
 *  PIC emulator.  12C509A version.
 *  Part 2, break original program in two for compatibility with other PICEMU
 *  flavors.
 *
 *  Copyright (c) 2001-2004
 *
 *  Released under the GNU GPL.  See http://www.gnu.org/licenses/gpl.txt
 *
 *  This program is part of PICEMU
 *
 *  PICEMU is free software; you can redistribute it and/or modify it under
 *  the terms of the GNU General Public License as published by the Free
 *  Software Foundatation; either version 2 of the License, or any later
 *  version.
 *
 *  PICEMU is distributed in the hope that it will be useful, but WITHOUT
 *  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 *  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 *  for more details.
 *
 *
 *  Revision history
 *
 *  Date      Comments
 *  --------  ---------------------------------------------
 *  8/xx/01   Original code
 *  11/14/01  Code cleanup for 1st BETA release
 *  1/3/03    Added cli/sti couple to avoid wrong PORT drawings on int9
 *  2/20/04   New commands, add analog inputs
 *  3/15/04   Source code unification for 14-bit core programs.
 */

#include <picemu.h>

extern WORD memory[MEMORY_SIZE];  /* program memory */

extern BYTE regs[NUM_REGS];

extern WORD xlate_regs[NUM_REGS];
extern BYTE (*readregs[NUM_REGS])();
extern BYTE r_none();  /* not used for 509A, but makes source more compatible */
#ifdef CORE_14BIT
   extern BYTE show_regs[NUM_REGS];  /* which regs to display */
#endif  /* CORE_14BIT */

extern BYTE input_ports[NUM_BYTE_PORTS_ALLOCATE];
extern BYTE port_masks[NUM_BYTE_PORTS_ALLOCATE];
extern WORD analog_ports[NUM_BYTE_PORTS][8];
/* extern BYTE port_screen[NUM_BYTE_PORTS_ALLOCATE * 9 * 3 * 2]; */
          /* use _ALLOCATE to keep things a multiple of 4 */
/* extern BYTE watch_screen[80 * 3 * 2]; */  /* 3 lines of 80 chars/attributes */
extern struct keypins key_pins[MAX_KEYPINS];

extern WORD stack[STACK_SIZE];
extern WORD stack_depth;
extern WORD max_stack_depth;

extern WORD opcode;        /* opcode we're working on */
extern WORD ip;            /* instruction pointer */
extern BYTE w;             /* Working register */
extern WORD filenum;       /* index into regs */
extern WORD dest;          /* 1=destination is F (register File) 0=destination is W */
extern WORD breakpoint;    /* !0, have breakpoint, else FALSE */
extern WORD sleepmode;     /* TRUE if sleeping, else FALSE */
extern WORD port_video_addr;    /* for port display */
extern WORD watch_video_addr;   /* for watch display */
extern BYTE temp1;         /* useful to have around */
#ifdef HAS_CMCON
   extern BYTE last_cout;  /* for comparitor interrupt */
#endif  /* HAS_CMCON */

extern WORD configuration;

extern WORD num_watch_regs;
extern WORD watch_regs_delay;
extern WORD watchregs[NUM_WATCHREGS];
/* extern WORD io_processing_busy; */
extern WORD io_processing_waiting;

extern BYTE instr_str[64];  /* disassembled instruction */

extern BYTE tempstr[STRING_SIZE];


/*  Note:  Even though these are only used for hardware UART emulation,
 *         define them anyway so that only 1 version of take_int9() is
 *         needed.
 */
extern WORD commport;
extern BYTE uart_in_queue[UART_QUEUE_SIZE+8];
extern WORD uart_in_queue_head;
extern WORD uart_in_queue_tail;

#ifdef HAS_UART
   extern BYTE old_uart_setup[8];

   WORD commbase = 0x0000;  /* default to SCREEN/KEYBOARD */
   WORD irqnum = 0;         /* default to SCREEN/KEYBOARD */
   DWORD baudrate = 9600;

   WORD comm_int_seg, comm_int_ofs;  /* save area */

   extern WORD tsr_hold_available; /* data is available in tsr_hold */
      /*
       * NOTE: This needs to be done for correct serial emulation.  Since
       *       TXREG moves it's data into into the TSR (transmit shift reg),
       *       and then immediately becomes available (i.e. sets TXIF) for
       *       new TX data, we can have a situation like this:
       *          ...
       *          while (outbuf_tail != outbuf_head)
       *             {
       *             if (TXIF)
       *                TXREG = outbuf[outbuf_tail++];
       *             }
       *          TXIE = 0;  //turn off TX interrupts
       *          TXEN = 0;  //turn off TSR (multidrop protocol)
       *          ...
       *       Why is this a problem?  Well, since TXIF is set when TXREG
       *       is moved into the TSR, we immediately move new data into TXREG,
       *       then notice our buffer is empty, so we turn off both TXIE
       *       (TX interrupt enable) and TXEN (turn off the TSR).  But this
       *       is done so fast that the PIC doesn't have time to send the data
       *       in the TSR, let alone the new data in TXREG.  So the last 2
       *       serial out chars are "dropped".  And since the PC serial port
       *       doesn't support turning off the TX, I'm going to fake it by not
       *       sending the character until half the char would have left the
       *       TSR, so that that the correct number of characters are dropped.
       *       (Though I can't simulate turning off the TSR in the middle of
       *       a char, so I can't simulate the framing error that would cause.)
       *
       *       Yes, the above code fragment could be fixed by:
       *          ...
       *          TXIE = 0;      // turn off TX interrupts
       *          while (!TRMT)  // wait until TSR empty
       *             ;
       *          TXEN = 0;     // turn off TSR (multidrop protocol)
       *          ...
       *       but the job of a interpreter/debugger is to let you find
       *       your errors, not do it right in spite of your errors.
       */
   extern WORD tx_data_available;  /* TXREG has fresh data */
   extern WORD tx_port_available;  /* TXREG ready to receive data */
   extern WORD tx_int_delay;   /* default: no delay */
   extern WORD tx_int_delay_counter;
   extern WORD winnt;
    /*   I'd better explain why I need to detect NT for serial I/O:
     *         MICRO$QUISH SUCKS!
     *
     *   Or, to be more explicit:  NT is trying to "protect" the hardware,
     *   so all I/O is virtualized.  This is a *SLOW* process.  When I do
     *   an outp() to send the char, it takes so long that, on a 600Mhz PIII,
     *   a basic interrupt driven serial I/O loop does not have time to do
     *   *ANYTHING* but the interrupt process, over and over.
     *
     *   So, I have to delay presenting the TX IRQ for a while, so that the
     *   rest of the program has a chance to run before servicing the next
     *   TX interrupt.
     */
#endif  /* HAS_UART */

extern WORD swap_screens;  /* swap screens for UART/SoftUart */
extern WORD screen_rowofs;
extern WORD screen_colofs;
            /* NOTE: screen_rowofs, screen_colofs are offsets into memory, not
             *       "row", and "col" numbers
             */
extern WORD hex_uart_screen;  /* TRUE or FALSE */
extern WORD hex_kbd_hold;     /* if hex_uart_screen, send hex from keyboard */
extern BYTE uart_screen[SCREEN_ROWS * SCREEN_COLS * 2];  /* *2 for char/attribute */
extern WORD uart_screen_maxrow;  /* max row to use for UART/SoftUART screen */
extern WORD uart_screen_maxrowofs;  /* max ofs to use for UART/SoftUART screen */
extern WORD cmdwindow_row;  /* keep track of row & col in command window */
extern WORD cmdwindow_col;

/* TX:  transmission from PIC --> USER */
/*  Note: su_txdata will start at 0, be right shifted before a new bit is
 *        put in the top of the word.  Thus, the received data will look like
 *        <stop bits><parity (if any)><data bits><start bit><0's>
 */
extern WORD su_txenable;    /* if 0, we are doing PIC --> USER bitbanging */
extern WORD su_txbaud;      /* baudrate, 110 to 57600 (max of frequency/16) */
extern WORD su_txport;      /* PORT used for TX pin */
extern WORD su_txpin;       /* bit in PORT for TX pin */
extern WORD su_txbittiming; /* instructions per bit */
extern WORD su_txcount;     /* count of bits received from PIC */
extern WORD su_txtiming;    /* if != 0, inst. count until next bit receive */
extern WORD su_txdatabits;  /* number of data bits we're expecting, 7 or 8 */
extern WORD su_txparity;    /* 'E'ven, 'N'one, or 'O'dd */
extern WORD su_txstopbits;  /* number of stop bits we're expecting, 1 or 2 */
extern WORD su_txtotalbits; /* total bits: 1 (start bit) + databits + stop bits + parity (if any) */
extern WORD su_txstopmask;  /* 0x8000 or 0xc000 for 1 or 2 stop bits (top of receive word) */
extern WORD su_txframemask; /* su_txstopmask | (1 << (16-txtotalbits)), check start bit for 0 as well as stop bits */
extern WORD su_txdatamask;  /* mask for 7/8 bit data: 0x7f or 0xff */
extern WORD su_txdatashift; /* bits to shift data to put it at the bottom of the low byte */
extern WORD su_txdata;      /* data we've received */
extern WORD su_txlastbit;   /* previous state of our TX pin, for start of data detection */
extern WORD su_txbitmask;   /* bittable[su_txpin] */
extern WORD su_txinvert;    /* 0x00 (normal) or 0xff (inverted) logic levels */
extern WORD doing_portwrite;  /* flag for io_processing and su_tx stuff */

/* RX:  transmission from USER --> PIC */
/*  Note: su_rxdata will start at contain the formatted bit string.  Bits
 *        will be read from the bottom of the word, which will then be
 *        shifted right.  Thus, the data to send will look like:
 *        <0's><stop bits><parity (if any)><data bits><start bit>
 */
extern WORD su_rxenable;    /* if 0, we are doing USER --> PIC bitbanging */
extern WORD su_rxbaud;      /* baudrate, 110 to 57600 (max of frequency/16) */
extern WORD su_rxport;      /* PORT used for TX pin */
extern WORD su_rxpin;       /* bit in PORT for TX pin */
extern WORD su_rxbittiming; /* instructions per bit */
extern WORD su_rxcount;     /* count of bits received from PIC */
extern WORD su_rxtiming;    /* if != 0, inst. count until next bit receive */
extern WORD su_rxdatabits;  /* number of data bits we're expecting, 7 or 8 */
extern WORD su_rxparity;    /* 'E'ven, 'N'one, or 'O'dd */
extern WORD su_rxstopbits;  /* number of stop bits we're expecting, 1 or 2 */
extern WORD su_rxtotalbits; /* total bits: 1 (start bit) + databits + stop bits + parity (if any) */
extern WORD su_rxstopmask;  /* 0x01 or 0x03 (1 or 2 stop bits) << (start+databits+paritybits) */
extern WORD su_rxdatamask;  /* mask for 7/8 bit data: 0x7f or 0xff */
extern WORD su_rxdata;      /* data we've received */
extern WORD su_rxbitmask;   /* bittable[su_rxpin] */
extern WORD su_rxinvert;    /* 0x00 (normal) or 0xffff (inverted) logic levels */
extern BYTE su_rx_in_queue[UART_QUEUE_SIZE+8];
extern WORD su_rx_in_queue_head;
extern WORD su_rx_in_queue_tail;

extern WORD show_ports;
extern WORD tickcount;  /* for timed run */
extern WORD have_tickcount;

extern void (*portbitfns[NUM_BYTE_PORTS*8])();

extern BYTE nl_str[];
extern WORD bytesperline;
extern WORD vesamode;  /* flag: VESA mode (0x010B -> 132 x 50) is available */
extern WORD windowmode;  /* FLAG: either VGA or VESA mode */
extern struct windata window_data[NUM_WINDOWS];

extern WORD oscope_lines;
extern WORD oscope_maxwidth;
extern WORD oscope_video_addr;    /* for oscope display */
extern WORD oscope_in;  /* IN index to oscope_data[] */
extern WORD oscope_out; /* OUT index to oscope_data[] */
extern WORD oscope_logical;
WORD oscope_data[MAX_OSCOPE_LINES][MAX_SCREEN_WIDTH];
WORD oscope_ports[MAX_OSCOPE_LINES];
WORD oscope_pins[MAX_OSCOPE_LINES];
WORD oscope_pinmasks[MAX_OSCOPE_LINES];
BYTE oscope_lastport[MAX_OSCOPE_LINES];
BYTE oscope_lasttris[MAX_OSCOPE_LINES];

extern WORD i2c_bytecount;
extern WORD i2c_bufindex;
extern BYTE i2c_databyte;
extern BYTE i2c_mode;
extern WORD scl_bitmask;
extern WORD i2c_hdr_size;
extern WORD i2c_addr_mask;
extern WORD i2c_address;
extern WORD i2c_page_mask;
extern WORD i2c_page_max;   /* i2c_page_max = i2c_hdr_size; if (i2c_type != 1) i2c_page_max += i2c_page_mask + 1; */
extern WORD i2c_seg;
   /* NOTE: Since I don't have enough RAM space in 64K to do an I2C EEPROM,
    *       and an EEPROM is something that takes time to access, I'm going
    *       to put it in "free" memory above PICEMU and access it manually.
    *
    *       If there isn't enough RAM for the I2C EEPROM, i2c_seg will
    *       be 0.
    */

extern WORD i2c_type;
extern BYTE i2c_buf[I2C_BUFSIZE];
extern WORD last_sda;
extern WORD last_sda_tris;
extern WORD last_scl;
extern WORD scl_pin;
extern WORD scl_pinmask;
extern WORD scl_port;
extern WORD sda_pin;
extern WORD sda_pinmask;
extern WORD sda_port;

       BYTE lasttris[NUM_BYTE_PORTS_ALLOCATE];  /* need this globally for reset_windows() */
static BYTE lastin[NUM_BYTE_PORTS_ALLOCATE];
static BYTE lastout[NUM_BYTE_PORTS_ALLOCATE];
static BYTE lastmask[NUM_BYTE_PORTS_ALLOCATE];

#ifdef HAS_VRCON
   extern WORD cvref;  /* Compare Voltage Reference */
   static BYTE lastvrcon;
#endif  /* HAS_VRCON */

#ifdef HAS_CMCON
   static BYTE lastcmcon[NUM_BYTE_PORTS_ALLOCATE];
   static BYTE lastcout;
   extern BYTE cmcon_porta_masks[CMCON_CONFIG_MASK+1];
   extern BYTE cmcon_porta_outputs[CMCON_CONFIG_MASK+1];
   extern BYTE cmcon_porta_whichcout[8];  /* indexed by bitnum in io_processing() */
#endif  /* HAS_CMCON */

#ifdef HAS_ADC
   static BYTE lastadcporta[NUM_BYTE_PORTS_ALLOCATE];
   extern BYTE adc_porta_masks[ADC_CONFIG_MASK+1];
   #ifdef HAS_PORTE
      static BYTE lastadcporte[NUM_BYTE_PORTS_ALLOCATE];
      extern BYTE adc_porte_masks[ADC_CONFIG_MASK+1];
   #endif  /* HAS_PORTE */
#endif  /* HAS_ADC */

static WORD analog_porthold[NUM_BYTE_PORTS][8];

BYTE ascii_hex(val)
   WORD val;
   {
   val &= 0x0f;
   if (val > 9)
      return(val + 0x37);
   return(val + 0x30);
   }

void add_tab()
    /* NOTE: I'm going to cheat here.  Since temp1 always contains the
     *       string length (ofs to EOS), I'm going to update that rather
     *       than passing a pointer to the length.
     */
   {
   temp1 = strlen(instr_str);  /* get EOS */
   do
      {
      instr_str[temp1++] = ' ';
      } while (temp1 & 7);
   instr_str[temp1] = '\0';  /* properly terminate string */
   }

void tabout(col)
   WORD col;
    /* NOTE: I'm going to cheat here.  Since temp1 always contains the
     *       string length (ofs to EOS), I'm going to update that rather
     *       than passing a pointer to the length.
     */
   {
   temp1 = strlen(instr_str);  /* get EOS */
   do
      {
      instr_str[temp1++] = ' ';
      } while (temp1 < col);
   instr_str[temp1] = '\0';  /* properly terminate string */
   }

void add_regname()
   {
   add_tab();
   sprintf(&instr_str[temp1],"%02x",filenum);
   }

void add_regname_w()
   {
   add_tab();
   sprintf(&instr_str[temp1],"%02x,%c",filenum,dest ? 'F' : 'W');
   }

void add_regname_b()
   {
   add_tab();
   sprintf(&instr_str[temp1],"%02x,%x",
       filenum,(opcode & BITNUM_MASK) >> BITNUM_POSITION);
   }

add_opcode_8bitconst()  /* add "\t<kkkk kkkk>" */
   {
   add_tab();
   sprintf(&instr_str[temp1],"%02x",opcode & 0xff);
   }

add_opcode_9bitconst()  /* add "\t<k kkkk kkkk>" */
   {
   add_tab();
   sprintf(&instr_str[temp1],"%03x",opcode & 0x1ff);
   }

void disasm_controls_12bit()
      /* 12bit:    000000 xx xxxx = NOP/OPTION/SLEEP/CLRWDT/TRIS/MOVWF
       * filenum = ...... .x xxxx
       * dest    = ...... x. ....
       * NOP     = 000000 00 0000
       * OPTION  = 000000 00 0010
       * SLEEP   = 000000 00 0011
       * CLRWDT  = 000000 00 0100
       * TRIS    = 000000 00 0110  <actually, 000000 00 0fff, but only fff=6 valid>
       * MOVWF   = 000000 1f ffff
       *   <unused opcodes will default to NOP>
       */
   {
   if (dest)  /* if dest set, this must be MOVWF */
      {
      strcat(instr_str,"MOVWF");
      add_regname();  /* add \t<regname>" */
      }
   else
      {
      switch (filenum)
         {
         case 0:  /* NOP */
            strcat(instr_str,"NOP");
            break;
         case 2:  /* OPTION */
            strcat(instr_str,"OPTION");
            break;
         case 3:  /* SLEEP */
            strcat(instr_str,"SLEEP");
            break;
         case 4:  /* CLRWDT */
            strcat(instr_str,"CLRWDT");
            break;
         case 6:  /* TRIS */
            strcat(instr_str,"TRIS");
/*            add_regname(); */  /* add \t<regname>" */
            break;
         default:
            strcat(instr_str,"NOPU");  /* Undefined opcode NOP */
            break;
         }
      }  /* if (dest) ... else */
   }

void disasm_clr_12bit()
      /* CLRW / CLRF = 000001 xx xxxx = CLRW / CLRF
       * filenum     = ...... .x xxxx
       * dest        = ...... x. ....
       * CLRW        = 000001 00 0000 <actually, 000001 0x xxxx
       * CLRF        = 000001 1f ffff
       */
   {
   if (!dest)  /* if W is destination */
      strcat(instr_str,"CLRW");
   else
      {
      strcat(instr_str,"CLRF");
      add_regname();  /* add \t<regname>" */
      }
   }

void disasm_subwf()            /* 000010 df ffff = SUBWF */
   {
   strcat(instr_str,"SUBWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_decf()             /* 000011 df ffff = DECF */
   {
   strcat(instr_str,"DECF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_iorwf()            /* 000100 df ffff = IORWF */
   {
   strcat(instr_str,"IORWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_andwf()            /* 000101 df ffff = ANDWF */
   {
   strcat(instr_str,"ANDWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_xorwf()            /* 000110 df ffff = XORWF */
   {
   strcat(instr_str,"XORWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_addwf()            /* 000111 df ffff = ADDWF */
   {
   strcat(instr_str,"ADDWF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_movf()             /* 001000 df ffff = MOVF */
   {
   strcat(instr_str,"MOVF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_comf()             /* 001001 df ffff = COMF */
   {
   strcat(instr_str,"COMF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_incf()             /* 001010 df ffff = INCF */
   {
   strcat(instr_str,"INCF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_decfsz()           /* 001011 df ffff = DECFSZ */
   {
   strcat(instr_str,"DECFSZ");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_rrf()              /* 001100 df ffff = RRF */
   {
   strcat(instr_str,"RRF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_rlf()              /* 001101 df ffff = RLF */
   {
   strcat(instr_str,"RLF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_swapf()            /* 001110 df ffff = SWAPF */
   {
   strcat(instr_str,"SWAPF");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_incfsz()           /* 001111 df ffff = INCFSZ */
   {
   strcat(instr_str,"INCFSZ");
   add_regname_w();  /* add \t<regname><f/w>" */
   }

void disasm_bcf()              /* 0100bb bf ffff = BCF <00b> */
   {
   strcat(instr_str,"BCF");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

void disasm_bsf()              /* 0100bb bf ffff = BSF <00b> */
   {
   strcat(instr_str,"BSF");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

void disasm_btfsc()            /* 0110bb bf ffff = BTFSC <00b> */
   {
   strcat(instr_str,"BTFSC");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

void disasm_btfss()            /* 0111bb bf ffff = BTFSS <00b> */
   {
   strcat(instr_str,"BTFSS");
   add_regname_b();  /* add \t<regname><bbb>" */
   }

void disasm_retlw()            /* 1000kk kk kkkk = RETLW <kkkk kkkk> */
   {
   strcat(instr_str,"RETLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   if (((opcode & 0xff) > ' ') && ((opcode & 0xff) < 0x80))
      {
      add_tab();
      sprintf(&instr_str[temp1],";%c",opcode & 0xff);
      }
   }

void disasm_call_12bit()       /* 1001kk kk kkkk = CALL <kkkk kkkk> */
   {
   strcat(instr_str,"CALL");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

void disasm_go_to_12bit()      /* 101kkk kk kkkk = GOTO <k kkkk kkkk> */
   {
   strcat(instr_str,"GOTO");
   add_opcode_9bitconst();  /* add "\t<k kkkk kkkk>" */
   }

void disasm_movlw()            /* 1100kk kk kkkk = MOVLW <kkkk kkkk> */
   {
   strcat(instr_str,"MOVLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

void disasm_iorlw()            /* 1101kk kk kkkk = IORLW <kkkk kkkk> */
   {
   strcat(instr_str,"IORLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

void disasm_andlw()            /* 1110kk kk kkkk = ANDLW <kkkk kkkk> */
   {
   strcat(instr_str,"ANDLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

void disasm_xorlw()            /* 1111kk kk kkkk = XORLW <kkkk kkkk> */
   {
   strcat(instr_str,"XORLW");
   add_opcode_8bitconst();  /* add "\t<kkkk kkkk>" */
   }

   static BYTE align_disasm_picops_1 = 1;
   static WORD align_disasm_picops_2 = 2;
void (*disasm_picops[1 << PIC_DECODE_BITS])() =
   {
   disasm_controls_12bit,   /* 000000 xx xxxx = NOP/OPTION/SLEEP/CLRWDT/TRIS/MOVWF */
   disasm_clr_12bit,        /* 000001 xx xxxx = CLRW / CLRF */
   disasm_subwf,            /* 000010 df ffff = SUBWF */
   disasm_decf,             /* 000011 df ffff = DECF */
   disasm_iorwf,            /* 000100 df ffff = IORWF */
   disasm_andwf,            /* 000101 df ffff = ANDWF */
   disasm_xorwf,            /* 000110 df ffff = XORWF */
   disasm_addwf,            /* 000111 df ffff = ADDWF */
   disasm_movf,             /* 001000 df ffff = MOVF */
   disasm_comf,             /* 001001 df ffff = COMF */
   disasm_incf,             /* 001010 df ffff = INCF */
   disasm_decfsz,           /* 001011 df ffff = DECFSZ */
   disasm_rrf,              /* 001100 df ffff = RRF */
   disasm_rlf,              /* 001101 df ffff = RLF */
   disasm_swapf,            /* 001110 df ffff = SWAPF */
   disasm_incfsz,           /* 001111 df ffff = INCFSZ */
   disasm_bcf,              /* 010000 bf ffff (0100bb bf ffff) = BCF <00b> */
   disasm_bcf,              /* 010001 bf ffff (0100bb bf ffff) = BCF <01b> */
   disasm_bcf,              /* 010010 bf ffff (0100bb bf ffff) = BCF <10b> */
   disasm_bcf,              /* 010011 bf ffff (0100bb bf ffff) = BCF <11b> */
   disasm_bsf,              /* 010100 bf ffff (0101bb bf ffff) = BSF <00b> */
   disasm_bsf,              /* 010101 bf ffff (0101bb bf ffff) = BSF <01b> */
   disasm_bsf,              /* 010110 bf ffff (0101bb bf ffff) = BSF <10b> */
   disasm_bsf,              /* 010111 bf ffff (0101bb bf ffff) = BSF <11b> */
   disasm_btfsc,            /* 011000 bf ffff (0110bb bf ffff) = BTFSC <00b> */
   disasm_btfsc,            /* 011001 bf ffff (0110bb bf ffff) = BTFSC <01b> */
   disasm_btfsc,            /* 011010 bf ffff (0110bb bf ffff) = BTFSC <10b> */
   disasm_btfsc,            /* 011011 bf ffff (0110bb bf ffff) = BTFSC <11b> */
   disasm_btfss,            /* 011100 bf ffff (0111bb bf ffff) = BTFSS <00b> */
   disasm_btfss,            /* 011101 bf ffff (0111bb bf ffff) = BTFSS <01b> */
   disasm_btfss,            /* 011110 bf ffff (0111bb bf ffff) = BTFSS <10b> */
   disasm_btfss,            /* 011111 bf ffff (0111bb bf ffff) = BTFSS <11b> */
   disasm_retlw,            /* 100000 kk kkkk (1000kk kk kkkk) = RETLW <00kk kkkk> */
   disasm_retlw,            /* 100001 kk kkkk (1000kk kk kkkk) = RETLW <01kk kkkk> */
   disasm_retlw,            /* 100010 kk kkkk (1000kk kk kkkk) = RETLW <10kk kkkk> */
   disasm_retlw,            /* 100011 kk kkkk (1000kk kk kkkk) = RETLW <11kk kkkk> */
   disasm_call_12bit,       /* 100100 kk kkkk (1001kk kk kkkk) = CALL <00kk kkkk> */
   disasm_call_12bit,       /* 100101 kk kkkk (1001kk kk kkkk) = CALL <01kk kkkk> */
   disasm_call_12bit,       /* 100110 kk kkkk (1001kk kk kkkk) = CALL <10kk kkkk> */
   disasm_call_12bit        /* 100111 kk kkkk (1001kk kk kkkk) = CALL <11kk kkkk> */
   disasm_go_to_12bit,      /* 101000 kk kkkk (101kkk kk kkkk) = GOTO <0 00kk kkkk> */
   disasm_go_to_12bit,      /* 101001 kk kkkk (101kkk kk kkkk) = GOTO <0 01kk kkkk> */
   disasm_go_to_12bit,      /* 101010 kk kkkk (101kkk kk kkkk) = GOTO <0 10kk kkkk> */
   disasm_go_to_12bit,      /* 101011 kk kkkk (101kkk kk kkkk) = GOTO <0 11kk kkkk> */
   disasm_go_to_12bit,      /* 101100 kk kkkk (101kkk kk kkkk) = GOTO <1 00kk kkkk> */
   disasm_go_to_12bit,      /* 101101 kk kkkk (101kkk kk kkkk) = GOTO <1 01kk kkkk> */
   disasm_go_to_12bit,      /* 101110 kk kkkk (101kkk kk kkkk) = GOTO <1 10kk kkkk> */
   disasm_go_to_12bit,      /* 101111 kk kkkk (101kkk kk kkkk) = GOTO <1 11kk kkkk> */
   disasm_movlw,            /* 110000 kk kkkk (1100kk kk kkkk) = MOVLW <00kk kkkk> */
   disasm_movlw,            /* 110001 kk kkkk (1100kk kk kkkk) = MOVLW <01kk kkkk> */
   disasm_movlw,            /* 110010 kk kkkk (1100kk kk kkkk) = MOVLW <10kk kkkk> */
   disasm_movlw,            /* 110011 kk kkkk (1100kk kk kkkk) = MOVLW <11kk kkkk> */
   disasm_iorlw,            /* 110100 kk kkkk (1101kk kk kkkk) = IORLW <00kk kkkk> */
   disasm_iorlw,            /* 110101 kk kkkk (1101kk kk kkkk) = IORLW <01kk kkkk> */
   disasm_iorlw,            /* 110110 kk kkkk (1101kk kk kkkk) = IORLW <10kk kkkk> */
   disasm_iorlw,            /* 110111 kk kkkk (1101kk kk kkkk) = IORLW <11kk kkkk> */
   disasm_andlw,            /* 111000 kk kkkk (1110kk kk kkkk) = ANDLW <00kk kkkk> */
   disasm_andlw,            /* 111001 kk kkkk (1110kk kk kkkk) = ANDLW <01kk kkkk> */
   disasm_andlw,            /* 111010 kk kkkk (1110kk kk kkkk) = ANDLW <10kk kkkk> */
   disasm_andlw,            /* 111011 kk kkkk (1110kk kk kkkk) = ANDLW <11kk kkkk> */
   disasm_xorlw,            /* 111100 kk kkkk (1111kk kk kkkk) = XORLW <00kk kkkk> */
   disasm_xorlw,            /* 111101 kk kkkk (1111kk kk kkkk) = XORLW <01kk kkkk> */
   disasm_xorlw,            /* 111110 kk kkkk (1111kk kk kkkk) = XORLW <10kk kkkk> */
   disasm_xorlw             /* 111111 kk kkkk (1111kk kk kkkk) = XORLW <11kk kkkk> */
   };

build_regdump_tempstr(start,end,use_showregs)
   WORD start, end, use_showregs;
   /* NOTE: use_showregs is not used for 509A, but is for higher processors */
   {
   WORD temp;
   WORD index;
   BYTE asciistr[32];

   index = 2;
   asciistr[0] = ' ';  /* be neat in formatting */
   asciistr[1] = ' ';
   for (temp = start; temp <= end; temp++)
      {
      if (xlate_regs[temp] != temp)  /* if mapped back to page 0 */
         {
         strcat(tempstr,"--");
         asciistr[index++] = ' ';
         }
      else
         {
         hexbyte(regs[xlate_regs[temp]],&tempstr[strlen(tempstr)]);
         if ((regs[xlate_regs[temp]] > ' ') && (regs[xlate_regs[temp]] <= '~'))
            asciistr[index++] = regs[xlate_regs[temp]];
         else
            asciistr[index++] = ' ';
         }
      if (temp == start+7)
         strcat(tempstr,"  ");
      else
         strcat(tempstr," ");
      }
   asciistr[index++] = '\n';
   asciistr[index] = '\0';  /* terminate string */
   strcat(tempstr,asciistr);
   }

get_stack_str()
   {
   WORD i;

   sprintf(tempstr,"stackdepth=%-5d  max stackdepth=%-5d:",
                 stack_depth,max_stack_depth);
   for (i = 0; i < STACK_SIZE; i++)
      sprintf(&tempstr[strlen(tempstr)]," %04x",stack[i]);
   }

get_status_str()
   {
   sprintf(tempstr,"W=%02x  IP=%04x  Status=%02x (bank=%d %s %s %s)  TRIS=%02x  OPT=%02x  CONF=%02x  %s\n",
            w,ip,regs[STATUS],
            (regs[FSR] & FSR_MEMORYPAGE_BITMASK) >> 5,
            (regs[STATUS] & STATUS_Z) ? "ZR" : "NZ",
            (regs[STATUS] & STATUS_DC) ? "DC" : "ND",
            (regs[STATUS] & STATUS_C) ? "CY" : "NC",
            regs[TRISA],regs[OPTION],configuration,
            (sleepmode) ? "SLEEP" : "");
   }

regdump(use_showregs)
   WORD use_showregs;
   /* NOTE: use_showregs is not used for 509A, but is for higher processors */
   {
   WORD i, j;

   get_stack_str();
   PUTS(tempstr);
   PUTS(nl_str);
   get_status_str();
   PUTS(tempstr);
   strcpy(tempstr,"00: ");
   build_regdump_tempstr(0x00,0x0f,TRUE);
   PUTS(tempstr);
   strcpy(tempstr,"10: ");
   build_regdump_tempstr(0x10,0x1f,TRUE);
   PUTS(tempstr);
   strcpy(tempstr,"    ");
   build_regdump_tempstr(0x20,0x2f,TRUE);
   PUTS(tempstr);
   strcpy(tempstr,"30: ");
   build_regdump_tempstr(0x30,0x3f,TRUE);
   PUTS(tempstr);
   }

get_instr_str(ip)
   WORD ip;
   {
   opcode = memory[ip] & INSTRUCTION_BITMASK;
   filenum = opcode & REGINDEX_MASK;  /* isolate register file */
   dest = opcode & DEST_MASK;  /* isolate F/!W bit */
   sprintf(instr_str,"%04x ",ip);
   add_symbol(ip,&instr_str[5]);
   tabout(18);
   sprintf(&instr_str[18],"%04x  ",opcode);
   (*disasm_picops[opcode >> OPTYPES_SHIFT])();  /* get 6 bits of instruction decode */
   }

show_instr(ip)
   WORD ip;
   {
   get_instr_str(ip);
   PUTS(instr_str);
   PUTS(nl_str);
   }

unassemble(startip,stopip)
   WORD startip, stopip;
   {
   while (startip != ((stopip+1)&MEMORY_MASK))
      {
      show_instr(startip++);
      startip &= MEMORY_MASK;
      }
   }

setup_softuart_rx()  /* called from our INT9 code, keep stack use small */
   {
   WORD ch, parity, i, mask;

   if (!su_rxtiming)  /* if not currently xmiting */
      {
      if (su_rx_in_queue_head == su_rx_in_queue_tail)
         return;   /* empty queue, we're done */
      ch = su_rx_in_queue[su_rx_in_queue_tail++];
      su_rx_in_queue_tail &= UART_QUEUE_MASK;  /* update queue ptr */
      su_rxdata = ((ch & su_rxdatamask) << 1)  /* set low bit to 0 for START bit */
                    | su_rxstopmask;  /* and include STOP bits */
      if (su_rxparity != 'N')  /* if Even or Odd */
         {
         parity = (su_rxparity == 'E') ? 0 : 1;
         for (i = 0; i < su_rxdatabits; i++, ch >>= 1)
            parity ^= ch & 1;
         su_rxdata |= parity << (su_rxdatabits + 1);
         }
      su_rxdata ^= su_rxinvert;  /* invert logic levels as needed */
      su_rxcount = 0;  /* bits we've sent */
      su_rxtiming = 1;  /* start xmit after next instr */
      }
   }

void take_int8()
   {
#asm
   push ds                         ;save our DS
   mov  ax,ds                      ;get ds
   mov  word cs:int8_ds_save,ax    ;save DS for interrupt use
   xor  ax,ax                      ;get a 0
   mov  ds,ax                      ;address INT seg
   mov  si,word [20h]              ;get current int ofs
   mov  di,word [22h]              ;get current int seg
   mov  word cs:int8ofs,si         ;save ofs
   mov  word cs:int8seg,di         ;and seg
   mov  word [20h],offset int8_int ;set new INT8 handler
   mov  word [22h],cs              ;and new INT8 seg
   pop  ds
   jmp  take_int8_end

int8_ds_save: dw 0
int8ofs:      dw 0
int8seg:      dw 0

int8_int:
   pushf                           ;save flags
   lcall cs:int8ofs                ;do original INT 8
   push ds                         ;save regs
   mov  ds,word cs:int8_ds_save    ;address program DS
   cmp  word tickcount_,0          ;already 0?
   jz   check_watch_regs           ;yes, skip this
   dec  word tickcount_            ;count this tick
   jnz  int8_over                  ;not done, quit
   mov  word breakpoint_,5         ;is 0, set breakpoint BRK_TIME
check_watch_regs:
   cmp  word num_watch_regs_,0     ;any watch regs?
   jz   int8_over                  ;no, we're done
   dec  word watch_regs_delay_     ;count this tick
   jnz  int8_over                  ;not done, skip this
   mov  word watch_regs_delay_,18  ;reset watch delay
   db   60h                        ;PUSHA
   push es                         ;save es
   call update_watch_display_      ;show watch regs
   pop  es                         ;restore es
   db   61h                        ;POPA
int8_over:
   pop  ds
   iret                            ;and done

take_int8_end:
#endasm
   }

void reset_int8()
   {
#asm
   mov  si,word cs:int8ofs         ;get ofs
   mov  di,word cs:int8seg         ;and seg
   push ds                         ;save our DS
   xor  ax,ax                      ;get a 0
   mov  ds,ax                      ;address INT seg
   cli                             ;do not distrub
   mov  word [20h],si              ;save int ofs
   mov  word [22h],di              ;and int seg
   sti                             ;ints are OK again
   pop  ds                         ;restore our DS
#endasm
   }

void take_int9()
   {
#asm
   push ds                         ;save our DS
   mov  ax,ds                      ;get ds
   mov  word cs:kbd_ds_save,ax     ;save DS for interrupt use
   xor  ax,ax                      ;get a 0
   mov  ds,ax                      ;address INT seg
   mov  si,word [24h]              ;get current int ofs
   mov  di,word [26h]              ;get current int seg
   mov  word cs:int9ofs,si         ;save ofs
   mov  word cs:int9seg,di         ;and seg
   mov  word [24h],offset kbd_int  ;set new INT9 handler
   mov  word [26h],cs              ;and new INT9 seg
   pop  ds
   jmp  take_int9_end

kbd_ds_save:  dw 0
int9ofs:      dw 0
int9seg:      dw 0

kbd_int:
   push  ax                        ;save ax
   in    al,60h                    ;get keyboard port
   push  ax                        ;save scancode
   pushf                           ;save flags
   lcall cs:int9ofs                ;do original INT 9
   push ds                         ;save regs
   push bx
   push si
   mov  ax,40h                     ;BIOS seg
   mov  ds,ax                      ;address BIOS seg
   mov  bx,word [1ah]              ;next char pointer
   cmp  bx,word [1ch]              ;1st free == next?
   jz   kbd_int_chkpin             ;yes, check I/O mapping
   mov  ax,word [bx]               ;get waiting char
   mov  word [1ch],bx              ;clear keyboard queue
   mov  bx,word [17h]              ;get keyboard flags
   mov  ds,word cs:kbd_ds_save     ;address program DS
   cmp  al,00h                     ;function key of some sort?
   je   kbd_int_chkpin             ;yes, don't pass it to serial port
   cmp  al,1bh                     ;is this ESC?
   jne  kbd_int_2                  ;no, continue
   test bl,1                       ;Right-Shift?
   jz   kbd_int_2                  ;no, continue
   mov  word breakpoint_,1         ;set breakpoint BRK_KEYPRESS
   jmp  kbd_int_end                ;and we're done
kbd_int_2:
   cmp  word hex_uart_screen_,0    ;doing HEX?
   je   kbd_int_2a                 ;no, continue
   cmp  al,'0'                     ;is this hex?
   jnae kbd_int_end                ;no, we're done
   cmp  al,'9'                     ;a digit?
   jna  kbd_int_savehex            ;yes, save it
   cmp  al,'A'                     ;a hex digit?
   jnae kbd_int_end                ;no, we're done
   cmp  al,'F'                     ;upper-case hex?
   jna  kbd_int_savehex            ;yes, save it
   cmp  al,'a'                     ;lower-case hex?
   jnae kbd_int_end                ;no, we're done
   cmp  al,'f'                     ;still lower-case hex?
   ja   kbd_int_end                ;no, we're done
kbd_int_savehex:
   or   al,20h                     ;force lower case
   sub  al,'0'                     ;get number
   cmp  al,9                       ;hex digit?
   jna  kbd_int_savehex2           ;no, skip this
   sub  al,27h                     ;get 0x0a .. 0x0f
kbd_int_savehex2:
   mov  ah,1                       ;make sure our flag is non-zero
   cmp  word hex_kbd_hold_,0       ;is this high digit?
   jne  kbd_int_havehex            ;no, save hex byte
   shl  al,1                       ;put hex digit in high nibble
   shl  al,1
   shl  al,1
   shl  al,1
   mov  word hex_kbd_hold_,ax      ;save nibble for next pass
   jmp  kbd_int_end                ;and we're done
kbd_int_havehex:
   or   al,byte hex_kbd_hold_      ;al = hex byte
   mov  word hex_kbd_hold_,0       ;reset flag for next digit
kbd_int_2a:
   cmp  word commport_,0           ;use SCREEN/KEYBOARD for "uart"?
   jne  kbd_int_chk_softuart       ;no, check for soft UART
   mov  bx,word uart_in_queue_head_ ;get head pointer
   mov  si,bx                      ;and a copy
   inc  bx                         ;update ptr
   and  bx,001fh                   ;mod queue size
   cmp  bx,word uart_in_queue_tail_ ;queue full?
   je   kbd_int_end                ;yes, throw this char away
   add  si,offset uart_in_queue_   ;setup ptr
   mov  byte [si],al               ;put into buff
   mov  word uart_in_queue_head_,bx ;set new pointer
   jmp  kbd_int_end                ;and we're done
kbd_int_chk_softuart:
   cmp  word su_rxenable_,0        ;using SoftUart?
   jne  kbd_int_end                ;no, we're done
   mov  bx,word su_rx_in_queue_head_  ;get head pointer
   mov  si,bx                      ;and a copy
   inc  bx                         ;update ptr
   and  bx,001fh                   ;mod queue size
   cmp  bx,word su_rx_in_queue_tail_ ;queue full?
   je   kbd_int_end                ;yes, throw this char away
   add  si,offset su_rx_in_queue_  ;setup ptr
   mov  byte [si],al               ;put into buf
   mov  word su_rx_in_queue_head_,bx  ;set new pointer
   db   60h                        ;PUSHA
   push es                         ;save es
   call setup_softuart_rx_         ;setup SoftUart character xmit USER -> PIC
   pop  es                         ;restore es
   db   61h                        ;POPA
   jmp  kbd_int_end                ;and we're done
kbd_int_chkpin:
   mov  ds,word cs:kbd_ds_save     ;address program DS
   push bp                         ;save stack frame
   mov  bp,sp                      ;setup stack frame
                    ;bp+08 -> ax
                    ;bp+06 -> ds
                    ;bp+04 -> bx
                    ;bp+02 -> si
                    ;bp+00 -> bp
   mov  ax,word [bp+8]             ;get PORT 60h value
   pop  bp                         ;restore BP
   mov  ah,al                      ;save raw scancode
   and  al,7fh                     ;strip press/release flag
   cmp  al,3bh                     ;F1 key?
   jnae kbd_int_end                ;< F1, we're done
   cmp  al,44h                     ;F10 key?
   ja   kbd_int_end                ;> F10, we're done
   mov  bh,0                       ;make BL a WORD
   mov  bl,al                      ;BX = scancode
   sub  bx,3bh                     ;BX = index (F1==0 .. F10==9)
   add  bx,bx                      ;BX * 2
   mov  si,bx                      ;save BX * 2
   add  bx,bx                      ;BX * 4
   add  bx,si                      ;BX * 6  (sizeof(struct keypin))
   add  bx,offset key_pins_        ;get ptr to structure element
   cmp  word [bx],0ffffh           ;keypins[Fkey].keytype == KEYMODE_UNUSED?
   je   kbd_int_end                ;yes, we're done
   rol  ax,1                       ;move press/release flag to low bit of AX
   and  ax,1                       ;clear all other AX bits
   cmp  word [bx],2                ;key_pins.keytype >= KEYMODE_TOGGLE?
   jnae kbd_int_chkpin2            ;no, skip this
   test al,1                       ;release flag?
   jnz  kbd_int_end                ;yes, can skip this
kbd_int_chkpin2:
   xor  ax,word [bx]               ;get set/release/toggle flag
   db   60h                        ;PUSHA
   push es                         ;save es
   push ax                         ;set/release/toggle flag to stack
   call word [bx+2]                ;call key_pins[Fkey].keyaction
   pop  ax                         ;cleanup stack
   cmp  word show_ports_,0         ;need to show port status?
   jne  kbd_int_show_status        ;yes, do it
   cmp  word windowmode_,0         ;doing windows?
   je   kbd_int_end_2              ;no, skip this
kbd_int_show_status:
;   cmp  word io_processing_busy_,0  ;safe to enter?
;   je   kbd_int_show_status_2             ;yes, go update screen
   mov  word io_processing_waiting_,1  ;set flag: need to update screen
;   jmp  kbd_int_end_2                     ;and done
;kbd_int_show_status_2:
;   call io_processing_             ;show port status
kbd_int_end_2:
   pop  es                         ;restore ES
   db   61h                        ;POPA

kbd_int_end:
;   mov  al,20h
;   out  20h,al
;   out  0a0h,al

   pop  si
   pop  bx
   pop  ds
   pop  ax
   pop  ax
   iret                            ;and done

take_int9_end:
#endasm
   }

void reset_int9()
   {
#asm
   mov  si,word cs:int9ofs         ;get ofs
   mov  di,word cs:int9seg         ;and seg
   push ds                         ;save our DS
   xor  ax,ax                      ;get a 0
   mov  ds,ax                      ;address INT seg
   cli                             ;do not distrub
   mov  word [24h],si              ;save int ofs
   mov  word [26h],di              ;and int seg
   sti                             ;ints are OK again
   pop  ds                         ;restore our DS
#endasm
   }

#ifdef HAS_UART
take_comm_interrupt()
   {
#asm
   mov  ax,ds                   ;get ds
   mov  word cs:dssave,ax       ;save DS for interrupt use

   mov  bx,word irqnum_         ;get IRQ number in use
   add  bx,8                    ;make it an INT number
   add  bx,bx                   ;*2
   add  bx,bx                   ;*4 for INT offset
   push ds                      ;save DS
   xor  ax,ax                   ;get a 0
   mov  ds,ax                   ;address INT seg
   mov  si,word [bx]            ;get current int ofs
   mov  di,word [bx+2]          ;get current int seg
   mov  word [bx],offset comm_int  ;set new int ofs
   mov  word [bx+2],cs          ;set new int seg
   pop  ds                      ;restore ds
   mov  word comm_int_ofs_,si   ;save old int ofs
   mov  word comm_int_seg_,di   ;save old int seg
   jmp  take_comm_interrupt_end ;and quit

dssave:  dw  0

comm_int:
   push ax                      ;save regs
   push bx
   push dx
   push si
   push ds
   mov  ds,cs:dssave            ;get local DS
;
tci_loop:
   mov  dx,word commbase_       ;get I/O port base
   add  dx,2                    ;up to INT_ID register
   in   al,dx                   ;get INT_ID register
   sub  dx,2                    ;back to I/O port base
   test al,1                    ;INT PENDING set?
   jnz  tci_over                ;no, we're done
   and  al,6h                   ;only want these 2 bits
   cmp  al,2                    ;a TX interrupt?
   jz   tci_tx_int              ;yes, go do it
   in   al,dx                   ;get COMM input char
   mov  bx,word uart_in_queue_head_  ;get head pointer
   mov  si,bx                   ;and a copy
   inc  bx                      ;update ptr
   and  bx,001fh                ;mod queue size
   cmp  bx,word uart_in_queue_tail_ ;queue full?
   je   tci_loop                ;yes, throw this char away
   add  si,offset uart_in_queue_ ;setup ptr
   mov  byte [si],al            ;put into buff
   mov  word uart_in_queue_head_,bx  ;set new pointer
   jmp  tci_loop                ;and done
tci_tx_int:
   mov  word tx_port_available_,1 ;set TRUE
   mov  ax,word tx_int_delay_   ;get delay
   mov  word tx_int_delay_counter_,ax  ;set delay counter
   inc  dx                      ;up to INT_EN port
   in   al,dx                   ;get interrupt flags
   and  al,0dh                  ;turn off TX interrupt
   out  dx,al                   ;and set INT_EN port
   jmp  tci_loop
tci_over:
;
   mov  al,20h
   out  20h,al
   out  0a0h,al
;
;   mov  dx,20h                  ;8259 I/O port
;   mov  ax,20h                  ;EOI signal
;   out  dx,al                   ;reset 8259
;
   pop  ds                      ;restore regs
   pop  si
   pop  dx
   pop  bx
   pop  ax
   iret

take_comm_interrupt_end:
#endasm
   }

WORD inp(portnum)
   WORD portnum;
   {
#asm
   mov  dx,word [bp+4]   ;get portnum
   in   al,dx            ;get BYTE port
   mov  ah,0             ;make it a WORD
#endasm
   }

outp(portnum,data)
   WORD portnum,data;
   {
#asm
   mov  dx,word [bp+4]       ;get port number
   mov  ax,word [bp+6]       ;get value (BYTE in AL)
   out  dx,al                ;send to I/O port
#endasm
   }

reset_comm_interrupt()
   {
   outp(0x21,inp(0x21) | (1 << irqnum));  /* disable COMM interrupts */
#asm
   mov  si,word comm_int_ofs_   ;get saved int ofs
   mov  di,word comm_int_seg_   ;get saved int seg
   mov  bx,word irqnum_         ;get IRQ number in use
   add  bx,8                    ;make it an INT number
   add  bx,bx                   ;*2
   add  bx,bx                   ;*4 for INT offset
   push ds                      ;save DS
   xor  ax,ax                   ;get a 0
   mov  ds,ax                   ;address INT seg
   mov  word [bx],si            ;get current int ofs
   mov  word [bx+2],di          ;get current int seg
   pop  ds                      ;restore ds
#endasm
   }

save_comm_port()
   {
   WORD status;

   old_uart_setup[UART_INT_EN] = inp(commbase+UART_INT_EN);
   outp(commbase+UART_INT_EN,0);  /* turn off comm interrupts */
   old_uart_setup[UART_LINE_CONTROL] = inp(commbase+UART_LINE_CONTROL);
   old_uart_setup[UART_MODEM_CONTROL] = inp(commbase+UART_MODEM_CONTROL);
   status = inp(commbase+UART_LINE_CONTROL);
   outp(commbase+UART_LINE_CONTROL,status|0x80);
   old_uart_setup[UART_BAUD_LSB] = inp(commbase+UART_BAUD_LSB);
   old_uart_setup[UART_BAUD_MSB] = inp(commbase+UART_BAUD_MSB);
   }

init_comm_port()
   {
   WORD status, divisor;

   outp(commbase+UART_LINE_CONTROL,inp(commbase+UART_LINE_CONTROL) | 0x80);
   divisor = UART_FREQUENCY / baudrate;
   outp(commbase+UART_BAUD_LSB,divisor & 0xff);
   outp(commbase+UART_BAUD_MSB,(divisor >> 8) & 0xff);
   status = 0x00;  /* mask: 0x38  0x00 -> parity = NONE */
   status |= 0x03;  /* mask: 0x03  0x03 -> data bits = 8 */
                    /* mask: 0x04  0x00 -> stop bits = 1 */
   outp(commbase+UART_LINE_CONTROL,status);  /* set data format */
   outp(commbase+UART_MODEM_CONTROL,UART_OUT2 | UART_DTR);  /* need to set these */
   outp(commbase+UART_INT_EN,UART_RX_INT);  /* allow interrupts */
   outp(0x21,inp(0x21) & ~(1 << irqnum));  /* enable COMM interrupts */
   }

disable_comm_port()
   {
   outp(commbase+UART_INT_EN,0);  /* disable interrupts */
   outp(commbase+UART_LINE_CONTROL,inp(commbase+UART_LINE_CONTROL) | 0x80);
   outp(commbase+UART_MODEM_CONTROL,0);  /* remove UART from 8259 */
   outp(0x21,inp(0x21) | (1 << irqnum));  /* disable COMM interrupts */
   tsr_hold_available = FALSE;  /* clear TSR */
   tx_data_available = FALSE;
   }

reset_comm_port()
   {
   outp(commbase+UART_INT_EN,0);  /* disable interrupts */
   outp(commbase+UART_MODEM_CONTROL,old_uart_setup[UART_MODEM_CONTROL]);
   outp(commbase+UART_LINE_CONTROL,inp(commbase+UART_LINE_CONTROL) | 0x80);
   outp(commbase+UART_BAUD_LSB,old_uart_setup[UART_BAUD_LSB]);
   outp(commbase+UART_BAUD_MSB,old_uart_setup[UART_BAUD_MSB]);
   outp(commbase+UART_LINE_CONTROL,old_uart_setup[UART_LINE_CONTROL]);
   }
#endif  /* HAS_UART */

screen_swap()
   {
   WORD r, c;  /* r = [BP-2], c = [BP-4] */
   WORD do_swap;
   WORD temp_curpos;

   do_swap = FALSE;
#ifdef HAS_UART
   if ((swap_screens) && ((!commport) || (!su_txenable)))
#else
   if ((swap_screens) && (!su_txenable))
#endif  /* HAS_UART */
      {
      do_swap = TRUE;
      temp_curpos = get_curpos();  /* get current cursor position */
      curpos(screen_rowofs/(SCREEN_COLS*2),screen_colofs/2);  /* set new position */
            /* NOTE: screen_rowofs, screen_colofs are offsets into memory, not
             *       "row", and "col" numbers
             */
      screen_rowofs = (temp_curpos >> 8) * (SCREEN_COLS * 2);  /* set screen offsets */
      screen_colofs = (temp_curpos & 0xff) * 2;
      }
#ifdef CORE_12BIT     /* if 12-bit PIC, ports are shown in both VESA and VGA */
   if ((!windowmode) && (show_ports))
#else
   if ((!vesamode) && (show_ports))  /* if VESA mode, ports are already shown */
#endif  /* CORE_12BIT */
      do_swap = TRUE;
   if ((!windowmode) && (num_watch_regs))  /* if window, watchregs already shown */
      do_swap = TRUE;
   if (oscope_lines)
      {
      do_swap = TRUE;
      if (oscope_maxwidth > SCREEN_COLS)
         {
         for (r = 50-MAX_OSCOPE_LINES; r < 50; r++)
            window_char(r,80,VERT_BAR|VIDEO_NORMAL);  /* repair screen divider */
         }
      }
   if (!do_swap)
      return;  /* no need to swap */
   r = window_data[WINDOW_COMMAND].startrow;
   c = window_data[WINDOW_COMMAND].startcol;
#asm
   push es                      ;save segments
   push ds
   push ds                      ;current dataseg
   pop  es                      ;to es
   mov  di,offset uart_screen_  ;es:di = our uart_screen
   mov  cx,word bytesperline_   ;get bytes per line
   mov  ax,word [bp-2]          ;get row
   mul  cx                      ;* bytes per line = offset
   add  ax,word [bp-4]          ;+ column
   add  ax,word [bp-4]          ;+ 2*column
   mov  si,ax                   ;ds:si = video screen
   cld                          ;up!
   mov  bx,25                   ;lines to swap
   mov  ax,0b800h               ;screen segment
   mov  ds,ax
   mov  dx,cx                   ;save bytes per line
screen_swap_1:
   push si                      ;save ptr into video mem
   mov  cx,80                   ;words to move
;   shr  cx,1                    ;words to move
screen_swap_loop:
   mov  ax,word es:[di]         ;get uart_screen word
   xchg ax,word [si]            ;swap wth video word
   stosw                        ;put into uart_screen
   inc  si                      ;update screen pointer
   inc  si
   loop screen_swap_loop        ;do entire screen
   pop  si                      ;get video screen ptr
   add  si,dx                   ;update screen ptr
;   mov  cx,dx                   ;restore bytes per line
   dec  bx                      ;count this line
   jnz  screen_swap_1           ;not done, do next line
   pop  ds                      ;restore segments
   pop  es
#endasm
   }

watch_videochar(ch)
   WORD ch;
   {
#asm
   push es                         ;save regs
   push di
   mov  ax,0b800h                  ;address video seg
   mov  es,ax
   mov  di,word watch_video_addr_  ;get dest ofs
   cld                             ;up!
   mov  al,byte [bp+4]             ;get char
   mov  ah,7                       ;normal attribute
   stosw                           ;put it into video memory
   mov  word watch_video_addr_,di  ;update dest ofs
   pop  di
   pop  es
#endasm
   }

update_watch_display()
   {
   WORD num, temp, startline;

   startline =
   watch_video_addr = window_data[WINDOW_WATCH].startrow * bytesperline
                + (window_data[WINDOW_WATCH].startcol << 1);
   for (num = 0; num < num_watch_regs; num++)
      {
      watch_videochar('0');
      watch_videochar(ascii_hex((temp = watchregs[num]) >> 4));
      watch_videochar(ascii_hex(temp));
      watch_videochar(':');
      watch_videochar(' ');
      watch_videochar(ascii_hex((temp = regs[xlate_regs[watchregs[num]]]) >> 4));
      watch_videochar(ascii_hex(temp));
      if ((num & 7) == 7)
         watch_video_addr = (startline += bytesperline);
      else
         {
         watch_videochar(' ');
         watch_videochar(' ');
         watch_videochar(' ');
         }
      }
   }

videochar(ch)
   BYTE ch;
   {
   if (ch == LF)
      {
      screen_rowofs += SCREEN_COLS * 2;
      screen_colofs = 0;
      }
   else
      if (ch == CR)
         screen_rowofs += SCREEN_COLS * 2;
      else
         {
         uart_screen[screen_rowofs+screen_colofs] = ch;
         if ((screen_colofs += 2) == SCREEN_COLS*2)
            {
            screen_colofs = 0;
            screen_rowofs += SCREEN_COLS * 2;
            }
         }
   if (screen_rowofs == uart_screen_maxrowofs)  /* if time to scroll */
      {
      screen_rowofs -= SCREEN_COLS * 2;
#asm
   push es              ;save seg
   push ds              ;data seg to es
   pop  es
   mov  di,offset uart_screen_  ;es:di = start of row 0
   lea  si,word [di+80*2]       ;ds:si = start of row 1
   mov  cx,word uart_screen_maxrowofs_  ;end of screen
   shr  cx,1            ;end of screen in words
   sub  cx,80           ;words to move
   cld                  ;up!
rep movsw               ;scroll uart_screen
   mov  ax,720h         ;space, normal attribute
   mov  cx,80           ;final row to fill
rep stosw
   pop  es
#endasm
      }
   }

uart_screen_char(ch)
   BYTE ch;
   {
   BYTE str[4];
   WORD i;

   if (hex_uart_screen)
      {
      str[0] = ascii_hex(ch >> 4);
      str[1] = ascii_hex(ch);
      str[2] = ' ';
      str[3] = '\0';
      }
   else
      {
      str[0] = ch;
      str[1] = '\0';
      }
   if (swap_screens)  /* if "UART screen" is active */
      {
      PUTS(str);  /* if I want more speed, I should write directly video memory */
      if (cmdwindow_row == uart_screen_maxrow)  /* time to scroll */
         {
         uartwindow_scroll(1);
         cmdwindow_row--;
         setcurpos(window_data[WINDOW_COMMAND].startrow+cmdwindow_row,
                      window_data[WINDOW_COMMAND].startcol+cmdwindow_col);
         }
      }
   else
      {
      for (i = 0; str[i]; i++)
         videochar(str[i]);  /* put char in "background" UART screen */
      myputsfile(str);  /* and to file echo, if needed */
      }
   }

#ifdef HAS_UART
send_byte(ch)
   BYTE ch;
   {
   BYTE str[4];
   WORD i;

   if (commbase)
      {
      outp(commbase+UART_INT_EN,UART_RX_INT | UART_TBE_INT);
                                                 /* enable RX/TX interrupts */
      outp(commbase,ch);
      }
   else
      {
      uart_screen_char(ch);
      }
   }
#endif  /* HAS_UART */

oscope_videochar(ch)
   WORD ch;
   {
#asm
   push es                    ;save regs
   push di
   mov  ax,0b800h                  ;video seg
   mov  es,ax                      ;to es
   mov  di,word oscope_video_addr_ ;get ptr into screen memory
   cld                             ;up!
   mov  al,byte [bp+4]             ;get char
   mov  ah,7                       ;set attribute
   stosw                           ;set char, attribute
   mov  word oscope_video_addr_,di ;update ptr into screen memory
   pop  di                         ;restore regs
   pop  es
#endasm
   }

show_oscope()
   {
   WORD num, index, addr_hold, addr_temp;
     /* num = word [BP-2] */

   addr_hold =
   addr_temp = oscope_video_addr;
   for (num = 0; num < oscope_lines; num++)
      {
      oscope_video_addr = addr_temp;
      addr_temp += bytesperline;
#ifdef PINS_8
      oscope_videochar('G'+oscope_ports[num]);
      oscope_videochar('P'+oscope_ports[num]);
      oscope_videochar('0'+oscope_pins[num]);
/*      oscope_videochar(' '); */
#else
      oscope_videochar('A'+oscope_ports[num]);
      oscope_videochar('0'+oscope_pins[num]);
      oscope_videochar(' ');
#endif  /* PINS_8 */
#asm
   push  es
   push  di
   push  si                     ;save regs
   mov   ax,132                 ;MAX_SCREEN_WIDTH
   mul   word [bp-2]            ;get index into oscope_data
   add   ax,ax                  ;*2 for WORD address
   add   ax,offset oscope_data_ ;get ptr into oscope data
   xchg  ax,si                  ;ds:si = data to show
   mov   ax,0b800h              ;video seg
   mov   es,ax
   mov   di,word oscope_video_addr_   ;es:di = ptr into video mem
   cld                          ;up!
   mov   bx,word oscope_out_    ;index = oscope_out
   add   bx,bx                  ;*2 for WORD address
   mov   cx,word oscope_in_     ;end when index == oscope_in
   add   cx,cx                  ;*2 for WORD address
   mov   dx,word oscope_maxwidth_  ;limit check
   add   dx,dx                  ;*2 for WORD address
show_oscope_loop:
   cmp   bx,cx                  ;at end of loop?
   je    s_o_l_1                ;yes, quit
   mov   ax,word [si+bx]        ;get char/attribute to show
   stosw                        ;put into video mem
   inc   bx                     ;update index
   inc   bx                     ;by 2 for WORD address
   cmp   bx,dx                  ;at limit?
   jne   show_oscope_loop       ;no, skip this
   xor   bx,bx                  ;set index to 0
   jmp   show_oscope_loop       ;and do next
s_o_l_1:
   pop   si                     ;restore regs
   pop   di
   pop   es
#endasm
      }
   oscope_video_addr = addr_hold;  /* reset for next time */
   }

#define OSCOPE_IN_HIGH  0x022d
#define OSCOPE_IN_LOW   0x025f
#define OSCOPE_OUT_HIGH 0x042d
#define OSCOPE_OUT_LOW  0x045f
update_oscope()
   {
   WORD num, ch, port, mask;

   for (num = 0; num < oscope_lines; num++)
      {
      port = oscope_ports[num];
      mask = oscope_pinmasks[num];
      if ((regs[TRISA+port] & mask)  /* if input pin */
#ifndef PICTYPE_16F648
                  || ((port == 0) && (mask == 0x80))  /* or MCLR */
#endif  /* PICTYPE_16F648 */
         )
         {
         if (input_ports[port] & mask)  /* if HIGH */
            ch = OSCOPE_IN_HIGH;
         else
            ch = OSCOPE_IN_LOW;
         }
      else
         {
         if (regs[PORTA+port] & mask)  /* if HIGH */
            ch = OSCOPE_OUT_HIGH;
         else
            ch = OSCOPE_OUT_LOW;
         }
      oscope_data[num][oscope_in] = ch;
      }
   if (++oscope_in == oscope_maxwidth)
      oscope_in = 0;
   if (oscope_in == oscope_out)  /* if time to update out pointer */
      if (++oscope_out == oscope_maxwidth)
         oscope_out = 0;
   show_oscope();
   }

port_videochar(ch_attrib)
   WORD ch_attrib;
   {
#asm
   push es                         ;save regs
   push di
   mov  ax,0b800h                  ;address video seg
   mov  es,ax
   mov  di,word port_video_addr_   ;get dest ofs
   cld                             ;up!
   mov  ax,word [bp+4]             ;get char/attrib
   stosw                           ;put it into video memory
   mov  word port_video_addr_,di   ;update dest ofs
   pop  di
   pop  es
#endasm
   }

port_analogvalue(val)
   WORD val;
   {
#asm
   push es                         ;save regs
   push di
   mov  ax,0b800h                  ;address video seg
   mov  es,ax
   mov  di,word port_video_addr_   ;get dest ofs
   add  di,word bytesperline_      ;next line
   cld                             ;up!
   mov  cl,4                       ;for 4 bit-shifts
   mov  al,byte [bp+5]             ;get value highbyte
   call p_av_byteout               ;show high byte (2 digits)
   mov  al,byte [bp+4]             ;get value lowbyte
   call p_av_byteout               ;show low byte (2 digits)
   jmp  p_av_done                  ;and done
p_av_byteout:
   mov  dl,al                      ;save low nibble
   shr  al,cl                      ;get high nibble
   call p_av_digitout              ;show it
   mov  al,dl                      ;get low nibble
p_av_digitout:
   and  al,0fh                     ;isolate low nibble
   add  al,90h                     ;trick 6-byte hex conversion
   daa
   adc  al,40h
   daa
   mov  ah,7                       ;standard video
   stosw                           ;put this into screen
   ret                             ;and done (with several subroutines)
p_av_done:
   pop  di
   pop  es
#endasm
   }

port_analogerase()
   {
#asm
   push es                         ;save regs
   push di
   mov  ax,0b800h                  ;address video seg
   mov  es,ax
   mov  di,word port_video_addr_   ;get dest ofs
   add  di,word bytesperline_      ;next line
   cld                             ;up!
   mov  cx,4                       ;for 4 bit-shifts
   mov  ax,0720h                   ;space, standard colors
   rep  stosw
   pop  di
   pop  es
#endasm
   }

i2c_address_decode()
   {
   if (i2c_hdr_size == I2C_ONEBYTE_ADDR)
      i2c_address = ((((WORD)i2c_buf[0] << 7) & 0x07) + (WORD)i2c_buf[1])
                                            & i2c_addr_mask;
   else
      i2c_address = (((WORD)i2c_buf[1] << 8) + (WORD)i2c_buf[2])
                                            & i2c_addr_mask;
   }

i2c_start()
   {
   if ((i2c_bytecount == i2c_hdr_size)
                && (i2c_mode == I2C_WRITE))  /* if sending addr for random read */
      i2c_address_decode();
   i2c_bytecount = 0;
   i2c_bufindex = 0;
   i2c_databyte = 0;
   i2c_mode = I2C_WRITE;  /* default */
   scl_bitmask = BIT7;
   }

i2c_stop()
   {
   WORD index;

   if (i2c_mode == I2C_WRITE)
      {
      if (i2c_bytecount > (index = i2c_hdr_size))
         {
         i2c_address_decode();
         for ( ; index < i2c_bytecount; index++)
            {
            pokeb(i2c_seg,i2c_address,i2c_buf[index]);
            i2c_address = (i2c_address & ~i2c_page_mask)
                               | ((i2c_address + 1) & i2c_page_mask);
            }
         }
      }
   i2c_mode = I2C_OFF;
   }

read_next_i2c_byte()
   {
   i2c_databyte = peekb(i2c_seg,i2c_address);
   i2c_address = (i2c_address + 1) & i2c_addr_mask;
   }

process_i2c_databyte()
   {
   if ((i2c_mode == I2C_WRITE) && (i2c_bufindex >= i2c_page_max))
      i2c_bufindex = i2c_hdr_size;
   if (i2c_bufindex < I2C_BUFSIZE)
      i2c_buf[i2c_bufindex++] = i2c_databyte;
   if ((++i2c_bytecount == 1)  /* if that was control byte */
           && (i2c_databyte & 1))  /* and R/!W == R */
      {
      i2c_mode = I2C_READ;
      read_next_i2c_byte();
      }
   if ((i2c_mode == I2C_WRITE) && (i2c_bytecount > i2c_page_max))
      i2c_bytecount--;
   }

#ifdef HAS_CMCON
   #ifdef PICTYPE_12F675
      WORD analog_or_output(pinmask,pinnum)
         WORD pinmask,pinnum;
         {
         if (regs[TRISA] & pinmask)  /* if an input */
            return(analog_ports[0][pinnum]);
         return((regs[PORTA] & pinmask) ? 0xffff : 0);
         }
    #endif  /* PICTYPE_12F675 */
    #ifdef PICTYPE_16F648
      WORD analog_or_output(pinmask,pinnum)
         WORD pinmask,pinnum;
         {
         if (regs[TRISA] & pinmask)  /* if an input */
            {
            if ((regs[VRCON] & VROE) && (pinmask == BIT2))
              /* if Vref is on A2, A2 is an input, and we're reading pin A2 */
               return(cvref);
            return(analog_ports[0][pinnum]);  /* return applied voltage */
            }
         return((regs[PORTA] & pinmask) ? 0xffff : 0);
         }
    #endif  /* PICTYPE_16F648 */
#endif  /* HAS_CMCON */

#define OUTPUT_HIGH  0x2700  /* O+: white on green */
#define OUTPUT_LOW   0x0400  /* O-: red on black */
#define INPUT_HIGH   0x7000  /* I+: black on white */
#define INPUT_LOW    0x0700  /* I-: white on black */
#define COMPAREPIN   0x0200  /* C : green on black */
#define ANALOGPIN    0x0300  /* A : cyan on black */
#define ANALOGOUT    0x3400  /* A : red on cyan */  /* VROE on A2, 16F648 */
/* NOTE: if you are familiar with the old code, this used to be called
 *       update_port_display().  The name was changed to reflect it's
 *       expanded functionality.
 */
io_processing()
   {
   WORD tris, inport, outport, mask, portnum, bit, bitnum, col;
   WORD adcporta, adcporte, cmcon;
   WORD sda, scl;  /* for I2C processing */
   WORD i, flag, pinmask;  /* for OSCOPE processing */
#ifdef HAS_CMCON
   WORD cmcon_mode, cmcon1_minus, cmcon1_plus;
   #ifdef HAS_CMP2
   WORD cmcon2_minus, cmcon2_plus;
   #endif  /* HAS_CMP2 */
#endif  /* HAS_CMCON */

/*   io_processing_busy = TRUE; */
      /* avoid reentrancy:  if this routine has been called from somewhere
       * (like w_gpio()) and a "pin toggle on keypress" comes along, global
       * variables used by this routine would be trashed.
       */
#ifdef PICTYPE_12C509A
   tris = regs[TRISA] | GP3;  /* get direction bits: 1=input, 0=output */
   if (regs[OPTION] & T0CS)  /* if T0CS, GP2 is an input despite TRIS */
      tris |= GP2;
#endif  /* PICTYPE_12C509A */
   if ((su_txenable == 0) && (doing_portwrite))  /* if SoftUart */
      {
#ifdef PICTYPE_12C509A
      if (!(tris & su_txbitmask))  /* if output pin */
#else
      if (!(regs[TRISA+su_txport] & su_txbitmask))  /* if output pin */
#endif  /* PICTYPE_12C509A */
         {
         if ((!(outport = (regs[PORTA+su_txport] ^ su_txinvert) & su_txbitmask))  /* if low */
                     && (!su_txtiming)   /* if not doing TX already! */
                     && (su_txlastbit))  /* and last state was high */
            {
            su_txcount = 0;  /* bits received */
            su_txdata = 0;   /* clear received data */
            su_txtiming = su_txbittiming >> 1;  /* check middle of expected bit */
            }
         su_txlastbit = outport;  /* get saved bit state */
         }
      }
   if ((i2c_type)
           && ((doing_portwrite)
#ifdef PICTYPE_12C509A
                  || ((tris & sda_pinmask) != last_sda_tris)))
#else
                  || ((regs[TRISA+sda_port] & sda_pinmask) != last_sda_tris)))
#endif  /* PICTYPE_12C509A */
                       /* if using I2C EEPROM */
      {
#ifdef PICTYPE_12C509A
      if (!(tris & scl_pinmask))  /* if OUTPUT */
#else
      if (!(regs[TRISA+scl_port] & scl_pinmask))  /* if OUTPUT */
#endif  /* PICTYPE_12C509A */
         scl = regs[PORTA+scl_port] & scl_pinmask;
      else
         scl = input_ports[scl_port] & scl_pinmask;
#ifdef PICTYPE_12C509A
      if (last_sda_tris = tris & sda_pinmask)  /* if Input */
#else
      if (last_sda_tris = regs[TRISA+sda_port] & sda_pinmask)  /* if Input */
#endif  /* PICTYPE_12C509A */
         sda = sda_pinmask;  /* Open Collector SDA must be HIGH */
      else
         sda = regs[PORTA+sda_port] & sda_pinmask;  /* use OUTPUT */
      if ((scl) && (sda != last_sda))  /* if START or STOP */
         {
         if (sda)
            i2c_stop();
         else
            i2c_start();
         }
      else  /* see if scl, take appropriate action */
         {
         if ((i2c_mode != I2C_OFF) && (scl != last_scl))  /* if sclock transition */
            {
            if (i2c_mode == I2C_READ)  /* if I2C EEPROM sending data to PIC */
               {
               if (!scl)  /* high-to-low transition */
                  {
                  if (!scl_bitmask)
                     {
                     if (!sda)  /* if ACK */
                        read_next_i2c_byte();
                     scl_bitmask = BIT7;  /* bitflag */
                     }
                  else
                     {
                     if (i2c_databyte & scl_bitmask)
                        input_ports[sda_port] |= sda_pinmask;
                     else
                        input_ports[sda_port] &= ~sda_pinmask;
                     scl_bitmask >>= 1;
                     }
                  }  /* if (!scl) */
               }
            else  /* PIC sending data to I2C EEPROM */
               {
               if (scl)  /* if low-to-high transition */
                  {
                  if (!scl_bitmask)
                     {
                     input_ports[sda_port] &= ~sda_pinmask;  /* send ACK */
                     scl_bitmask = BIT7;  /* bitflag */
                     process_i2c_databyte();
                     }
                  else
                     {
                     i2c_databyte <<= 1;
                     if (sda)
                        i2c_databyte |= 1;
                     scl_bitmask >>= 1;
                     }
                  }  /* if (!scl) */
               }  /* if (i2c_mode == I2C_READ) ... else */
            }  /* if (scl != last_scl) */
         }  /* if ((scl) && (sda != last_sda)) ... else */
      last_sda = sda;
      last_scl = scl;
      } /* if ((i2c_type) && (doing_portwrite)) */
   if (oscope_logical)   /* if update oscope on logic change */
      {
      for (flag = FALSE, i = 0; i < oscope_lines; i++)
         {
         pinmask = oscope_pinmasks[i];
         portnum = oscope_ports[i];
#ifdef PICTYPE_12C509A
         if ((bit = tris & pinmask) != oscope_lasttris[i])
#else
         if ((bit = regs[TRISA+portnum] & pinmask) != oscope_lasttris[i])
#endif  /* PICTYPE_12C509A */
            {
            flag = TRUE;
            oscope_lasttris[i] = bit;
            }
         if (bit)  /* if INPUT */
            bit = input_ports[portnum] & pinmask;
         else
            bit = regs[PORTA+portnum] & pinmask;
         if (bit != oscope_lastport[i])
            {
            flag = TRUE;
            oscope_lastport[i] = bit;
            }
         }
      if (flag)
         update_oscope();
      }  /* if (oscope_logical) */
#ifdef HAS_CMCON
   #ifdef HAS_CMP2
      regs[CMCON] &= 0x3f;  /* ~(C1OUT|C2OUT) damned compiler bug... */
   #else
      regs[CMCON] &= ~C1OUT;
   #endif  /* HAS_CMP2 */
   if (((cmcon_mode = regs[CMCON] & CMCON_CONFIG_MASK) != 0) && (cmcon_mode != 0x07))
                  /* if comparitor on */
      {
      switch (cmcon_mode)
         {
   #ifdef PICTYPE_12F675
         case 1:  /* C1_PLUS is C1P, C1_MINUS is C1M, C1OUT goes to GP2 */
         case 2:  /* C1_PLUS is C1P, C1_MINUS is C1M */
            cmcon1_minus = analog_or_output(C1_MINUS_PINMASK,C1_MINUS_PINNUM);
            cmcon1_plus = analog_or_output(C1_PLUS_PINMASK,C1_PLUS_PINNUM);
            break;
         case 3:  /* C1_PLUS is Vref, C1_MINUS is C1M, C1OUT goes to GP2 */
         case 4:  /* C1_PLUS is Vref, C1_MINUS is C1M */
            cmcon1_minus = analog_or_output(C1_MINUS_PINMASK,C1_MINUS_PINNUM);
            cmcon1_plus = cvref;
            break;
         case 5:  /* C1_PLUS is Vref, C1_MINUS is C1M(CIS=0)/C1P(CIS=1), C1OUT goes to CP2 */
         case 6:  /* C1_PLUS is Vref, C1_MINUS is C1M(CIS=0)/C1P(CIS=1) */
            if (regs[CMCON] & CIS)
               cmcon1_minus = analog_or_output(C1_PLUS_PINMASK,C1_PLUS_PINNUM);
            else
               cmcon1_minus = analog_or_output(C1_MINUS_PINMASK,C1_MINUS_PINNUM);
            cmcon1_plus = cvref;
            break;
   #endif  /* PICTYPE_12F675 */
   #ifdef PICTYPE_16F648
         case 1:  /* C1_PLUS is C2P, C1_MINUS is C1M(CIS=0)/C1P(CIS=1)
                   * C2_PLUS is C2P, C2_MINUS is C2M
                   */
            if (regs[CMCON] & CIS)
               cmcon1_minus = analog_or_output(C1_PLUS_PINMASK,C1_PLUS_PINNUM);
            else
               cmcon1_minus = analog_or_output(C1_MINUS_PINMASK,C1_MINUS_PINNUM);
            cmcon1_plus =
            cmcon2_plus = analog_or_output(C2_PLUS_PINMASK,C2_PLUS_PINNUM);
            cmcon2_minus = analog_or_output(C2_MINUS_PINMASK,C2_MINUS_PINNUM);
            break;
         case 2:  /* C1_PLUS is Vref, C1_MINUS is C1M(CIS=0)/C1P(CIS=1)
                   * C2_PLUS is Vref, C2_MINUS is C2M(CIS=0)/C2P(CIS=1)
                   */
            cmcon1_plus =
            cmcon2_plus = cvref;
            if (regs[CMCON] & CIS)
               {
               cmcon1_minus = analog_or_output(C1_PLUS_PINMASK,C1_PLUS_PINNUM);
               cmcon2_minus = analog_or_output(C2_PLUS_PINMASK,C2_PLUS_PINNUM);
               }
            else
               {
               cmcon1_minus = analog_or_output(C1_MINUS_PINMASK,C1_MINUS_PINNUM);
               cmcon2_minus = analog_or_output(C2_MINUS_PINMASK,C2_MINUS_PINNUM);
               }
            break;
         case 3:  /* C1_PLUS is C2P, C1_MINUS is C1M
                   * C2_PLUS is C2P, C2_MINUS is C2M
                   */
            cmcon1_minus = analog_or_output(C1_MINUS_PINMASK,C1_MINUS_PINNUM);
            cmcon1_plus =
            cmcon2_plus = analog_or_output(C2_PLUS_PINMASK,C2_PLUS_PINNUM);
            cmcon2_minus = analog_or_output(C2_MINUS_PINMASK,C2_MINUS_PINNUM);
            break;
         case 4:  /* C1_PLUS is C1P, C1_MINUS is C1M
                   * C2_PLUS is C2P, C2_MINUS is C2M
                   */
            cmcon1_plus = analog_or_output(C1_PLUS_PINMASK,C1_PLUS_PINNUM);
            cmcon1_minus = analog_or_output(C1_MINUS_PINMASK,C1_MINUS_PINNUM);
            cmcon2_plus = analog_or_output(C2_PLUS_PINMASK,C2_PLUS_PINNUM);
            cmcon2_minus = analog_or_output(C2_MINUS_PINMASK,C2_MINUS_PINNUM);
            break;
         case 5:  /* C1_PLUS is OFF, C2_MINUS is OFF
                   * C2_PLUS is C2P, C2_MINUS is C2M
                   */
            cmcon2_plus = analog_or_output(C2_PLUS_PINMASK,C2_PLUS_PINNUM);
            cmcon2_minus = analog_or_output(C2_MINUS_PINMASK,C2_MINUS_PINNUM);
            break;
         case 6:  /* C1_PLUS is C2P, C1_MINUS is C1M, C1OUT is on C1P
                   * C2_PLUS is C2P, C2_MINUS is C2M, C2OUT is on RA4
                   */
            cmcon1_minus = analog_or_output(C1_MINUS_PINMASK,C1_MINUS_PINNUM);
            cmcon1_plus =
            cmcon2_plus = analog_or_output(C2_PLUS_PINMASK,C2_PLUS_PINNUM);
            cmcon2_minus = analog_or_output(C2_MINUS_PINMASK,C2_MINUS_PINNUM);
            break;
   #endif  /* PICTYPE_16F648 */
         }  /* switch (cmcon_mode) */
   #ifdef HAS_CMP2
      if (cmcon_mode != 5)  /* for 16F648 mode 5, CMP1 is OFF */
         {
   #endif  /* HAS_CMP2 */
         if (cmcon1_plus > cmcon1_minus)  /* do compare */
            regs[CMCON] |= C1OUT;
         if (regs[CMCON] & C1INV)   /* invert if necessary */
            regs[CMCON] ^= C1OUT;
   #ifdef HAS_CMP2
         }
   #endif  /* HAS_CMP2 */
   #ifdef HAS_CMP2
      if (cmcon2_plus > cmcon2_minus)  /* do compare */
         regs[CMCON] |= C2OUT;
      if (regs[CMCON] & C2INV)   /* invert if necessary */
         regs[CMCON] ^= C2OUT;
   #endif  /* HAS_CMP2 */
      }  /* if (((cmcon_mode = regs[CMCON] & CMCON_CONFIG_MASK) != 0)...) */
   #ifdef HAS_CMP2
   if (last_cout != (regs[CMCON] & 0xc0))  /* (C1OUT|C2OUT) damned compiler bug */
                                           /* if comparitor output has changed */
   #else
   if (last_cout != (regs[CMCON] & C1OUT))  /* if comparitor output has changed */
   #endif  /* HAS_CMP2 */
      regs[PIR1] |= CMIF;  /* set comparitor interrupt flag */
#endif  /* HAS_CMCON */
   if ((!show_ports) && (!(window_data[WINDOW_PORTS].flags & WINDOW_DISPLAYED)))
      {
/*      io_processing_busy = FALSE; */
      return;
      }
   for (portnum = 0; portnum < NUM_BYTE_PORTS; portnum++)
      {
      inport = input_ports[portnum];  /* get input bits */
      outport = regs[PORTA+portnum];  /* get output bits */
      mask = port_masks[portnum];  /* which bits are available to show */
#ifndef PICTYPE_12C509A
      tris = regs[TRISA+portnum];  /* get direction bits: 1=input, 0=output */
#endif  /* PICTYPE_12C509A */
#ifdef HAS_CMCON
      if (portnum == 0)  /* PORTA */
         cmcon = cmcon_porta_masks[regs[CMCON]&CMCON_CONFIG_MASK];
      else
         cmcon = 0xff;  /* all digital */
#endif  /* HAS_CMCON */
#ifdef HAS_ADC
      if (portnum == 0)  /* PORTA */
   #ifdef HAS_ANSEL
         adcporta = adc_porta_masks[regs[ANSEL]&ADC_CONFIG_MASK];
   #else
         adcporta = adc_porta_masks[regs[ADCON1]&ADC_CONFIG_MASK];
   #endif  /* HAS_ANSEL */
      else
         adcporta = 0xff;  /* all digital */
   #ifdef HAS_PORTE
      if (portnum == 4)  /* PORTE */
         adcporte = adc_porte_masks[regs[ADCON1]&ADC_CONFIG_MASK];
      else
         adcporte = 0xff;  /* all digital */
   #endif  /* HAS_PORTE */
#endif  /* HAS_ADC */
      port_video_addr = (window_data[WINDOW_PORTS].startrow + portnum + portnum) * bytesperline
                + (window_data[WINDOW_PORTS].startcol << 1);
#ifdef PINS_8
      port_videochar('G'+portnum+VIDEO_NORMAL);
      port_videochar('P'+portnum+VIDEO_NORMAL);
      port_video_addr += 2;  /* skip 1 space */
#else
      port_videochar('A'+portnum+VIDEO_NORMAL);
      port_video_addr += 4;  /* skip 2 spaces */
#endif  /* PINS_8 */
      if ((tris == lasttris[portnum])
                  && (inport == lastin[portnum])
                  && (outport == lastout[portnum]) 
                  && (mask == lastmask[portnum])
#ifdef HAS_CMCON
                  && (cmcon == lastcmcon[portnum])
#ifdef HAS_CMP2
                  && ((regs[CMCON] & 0xc0) == lastcout)  /* 0xc0 == (C1OUT|C2OUT), damned bug */
#else
                  && ((regs[CMCON] & C1OUT) == lastcout)
#endif  /* HAS_CMP2 */
#endif  /* HAS_CMCON */
#ifdef HAS_VRCON
                  && (lastvrcon == regs[VRCON])
#endif  /* HAS_VRCON */
#ifdef HAS_ADC
                  && (adcporta == lastadcporta[portnum])
   #ifdef HAS_PORTE
                  && (adcporte == lastadcporte[portnum])
   #endif  /* HAS_PORTE */
#endif  /* HAS_ADC */
                  && (memcmp(&analog_ports[portnum],&analog_porthold[portnum],8*sizeof(WORD)) == 0)
          )
         continue;  /* no change, can skip this port */
      lasttris[portnum] = tris;
      lastin[portnum] = inport;
      lastout[portnum] = outport;  /* set flags for next pass */
      lastmask[portnum] = mask;  /* set flags for next pass */
#ifdef HAS_CMCON
      lastcmcon[portnum] = cmcon;
#ifdef HAS_CMP2
      lastcout = regs[CMCON] & 0xc0;  /* (C1OUT|C2OUT), damned bug... */
#else
      lastcout = regs[CMCON] & C1OUT;
#endif  /* HAS_CMP2 */
#endif  /* HAS_CMCON */
#ifdef HAS_VRCON
      lastvrcon = regs[VRCON];
#endif  /* HAS_VRCON */
#ifdef HAS_ADC
      lastadcporta[portnum] = adcporta;
   #ifdef HAS_PORTE
      lastadcporte[portnum] = adcporte;
   #endif  /* HAS_PORTE */
#endif  /* HAS_ADC */
      MEMMOVE(&analog_ports[portnum],&analog_porthold[portnum],8*sizeof(WORD));
      for (bitnum = 7, bit = 0x80; bit; bit >>= 1, bitnum--)
         {
         if (mask & bit)  /* if OK to display */
            {
#ifdef HAS_CMCON
            if (!(cmcon & bit))  /* if compare */
               {
               port_analogvalue(analog_ports[portnum][bitnum]);
               port_videochar('C'+COMPAREPIN);
               port_videochar(' '+VIDEO_NORMAL);
               }
            else
#endif  /* HAS_CMCON */
#ifdef HAS_ADC
            if (!(adcporta & bit)
#ifdef HAS_PORTE
                    || (!(adcporte & bit))
#endif  /* HAS_PORTE */
               )
               {
               port_analogvalue(analog_ports[portnum][bitnum]);
               port_videochar('A'+ANALOGPIN);
               port_videochar(' '+VIDEO_NORMAL);
               }
            else
#endif  /* HAS_ADC */
            if ((tris & bit)  /* if an input */
#ifndef PICTYPE_16F648
   #ifndef PICTYPE_12F675
                      || ((portnum == 0) && (bit == 0x80))  /* or MCLR */
   #endif  /* PICTYPE_12F675 */
#endif  /* PICTYPE_16F648 */
                            )
               {
#ifdef HAS_VRCON
   #ifdef VROE
               if ((portnum == 0) && (bitnum == 2) && (regs[VRCON] & VROE))
                  /* if A2 is INPUT and VROE is set */
                  {
                  port_analogvalue(cvref);
                  port_videochar('A'+ANALOGOUT);
                  port_videochar(' '+VIDEO_NORMAL);
                  }
               else
                  {
   #endif  /* VROE */
#endif  /* HAS_VRCON */
                  port_analogvalue(analog_ports[portnum][bitnum]);
                  if (inport & bit)
                     {
                     port_videochar('I'+INPUT_HIGH);
                     port_videochar('+'+INPUT_HIGH);
                     }
                  else
                     {
                     port_videochar('I'+INPUT_LOW);
                     port_videochar('-'+INPUT_LOW);
                     }
#ifdef HAS_VRCON
   #ifdef VROE
                  }
   #endif  /* VROE */
#endif  /* HAS_VRCON */
               }
            else  /* it's an output */
               {
               port_analogerase();
#ifdef HAS_CMCON
               if ((portnum == 0) && (bit & cmcon_porta_outputs[cmcon_mode]))
                  {
                  if (regs[CMCON] & cmcon_porta_whichcout[bitnum])
                     {
                     port_videochar('O'+OUTPUT_HIGH);
                     port_videochar('+'+OUTPUT_HIGH);
                     }
                  else
                     {
                     port_videochar('O'+OUTPUT_LOW);
                     port_videochar('-'+OUTPUT_LOW);
                     }
                  }
               else
#endif  /* HAS_CMCON */
                  if (outport & bit)
                     {
                     port_videochar('O'+OUTPUT_HIGH);
                     port_videochar('+'+OUTPUT_HIGH);
                     }
                  else
                     {
                     port_videochar('O'+OUTPUT_LOW);
                     port_videochar('-'+OUTPUT_LOW);
                     }
               }
            }
         else
            {
            port_analogerase();
            port_videochar(' '+VIDEO_NORMAL);
            port_videochar(' '+VIDEO_NORMAL);
            }
         port_video_addr += 6;  /* skip 3 spaces */
         }  /* for (bitnum = 7, bit = 0x80; bit; bit >>= 1, bitnum--) */
      }  /* for (portnum = 0; portnum < NUM_BYTE_PORTS; portnum++) */
/*   io_processing_busy = FALSE; */
   }

#ifdef HAS_UART
check_winnt()
   {
#asm
   mov  ax,3000h           ;fn = get DOS version
                           ;NOTE:al = 0 --> return OEM in BH (DOS 5.0+)
   int  21h                ;call DOS
   cmp  al,5               ;major version is DOS 5?
   jnae check_winnt_exit   ;no, we're done
   cmp  bh,0ffh            ;OEM = Microsoft?
   jne  check_winnt_exit   ;no, we're done
   mov  ax,3306h           ;fn = get true DOS version
   int  21h                ;call DOS
   cmp  al,0ffh            ;really is DOS 5.0+?
   je   check_winnt_exit   ;no, we're done
   cmp  bx,3205h           ;Version = 5.50?  (NT DOS box)
   jnz  check_winnt_exit   ;no, we're done
   mov  word winnt_,1      ;set winnt to TRUE
check_winnt_exit:
#endasm
   }
#endif  /* HAS_UART */
